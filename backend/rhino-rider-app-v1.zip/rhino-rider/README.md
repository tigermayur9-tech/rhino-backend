# Rhino — Rider App

Uber-style ride-hailing rider app. Uses the same live backend as the
Rhino Driver app: `https://rhino-backend-78xq.onrender.com`.

## What works (live backend)

- **Booking flow**: pickup auto-set from GPS, tap map for drop-off,
  live fare estimate (Ride / Comfort / XL), request a ride.
- **Tracking**: realtime status (looking → on the way → arriving →
  in progress → completed) + live blue driver dot via WebSocket.
- **Activity**: ride history for this app session (needs the backend
  `GET /api/riders/:riderId/rides` endpoint deployed).
- **Home**: Rhino/Parcel tabs, "Where to?" search, recent places,
  "For you" grid (Trip tile is live).

## What's visual-only (coming soon)

Auto, Store pick-up, Bike Saver, Parcel, Rentals, Seniors, Teens,
Schedule, Intercity, Bus & Train, Metro, saved-place hearts, Later
scheduling, and every Account menu row.

## Build

```bash
npm install
set EAS_NO_VCS=1        # Windows only — no Git installed
eas build -p android --profile preview   # test APK
eas build -p android --profile production # Play Store AAB
```

## Backend note

For ride history to work, the backend must expose
`GET /api/riders/:riderId/rides` (added to `backend/server.js`).
Render auto-deploys from GitHub on push.
