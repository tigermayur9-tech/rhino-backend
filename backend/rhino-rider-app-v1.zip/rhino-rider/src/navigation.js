/**
 * Navigation — React Navigation.
 *
 * Structure:
 *   Stack (full screen):
 *     Tabs (floating pill bar) -> Home / Services / Activity / Account
 *     Search -> Booking -> Tracking   (pushed on top of the tabs)
 *
 * The floating tab bar: white pill, black active capsule (icon + label),
 * icon-only when inactive — Uber style.
 */
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { colors, radii } from './theme';

import HomeScreen from './screens/HomeScreen';
import ServicesScreen from './screens/ServicesScreen';
import ActivityScreen from './screens/ActivityScreen';
import AccountScreen from './screens/AccountScreen';
import SearchScreen from './screens/SearchScreen';
import BookingScreen from './screens/BookingScreen';
import TrackingScreen from './screens/TrackingScreen';

export const ROUTES = {
  Home: 'Home',
  Services: 'Services',
  Activity: 'Activity',
  Account: 'Account',
  Search: 'Search',
  Booking: 'Booking',
  Tracking: 'Tracking',
};

const Tabs = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const TAB_ICONS = {
  Home: ['home', 'home-outline'],
  Services: ['grid', 'grid-outline'],
  Activity: ['receipt', 'receipt-outline'],
  Account: ['person', 'person-outline'],
};

function FloatingTabBar({ state, descriptors, navigation }) {
  return (
    <View style={styles.tabWrap} pointerEvents="box-none">
      <View style={styles.tabBar}>
        {state.routes.map((route, index) => {
          const focused = state.index === index;
          const options = descriptors[route.key].options;
          const icon = TAB_ICONS[route.name] || ['ellipse', 'ellipse-outline'];
          const label = options.tabBarLabel ?? route.name;
          const onPress = () => {
            const event = navigation.emit({
              type: 'tabPress',
              target: route.key,
              canPreventDefault: true,
            });
            if (!focused && !event.defaultPrevented) navigation.navigate(route.name);
          };
          return (
            <TouchableOpacity
              key={route.key}
              onPress={onPress}
              style={styles.tabItem}
              activeOpacity={0.7}
            >
              <View style={[styles.tabInner, focused && styles.tabInnerActive]}>
                <Ionicons
                  name={focused ? icon[0] : icon[1]}
                  size={22}
                  color={focused ? '#FFFFFF' : colors.tabInactive}
                />
                {focused && <Text style={styles.tabLabel}>{label}</Text>}
              </View>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

function TabsNavigator() {
  return (
    <Tabs.Navigator
      tabBar={(props) => <FloatingTabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tabs.Screen name={ROUTES.Home} component={HomeScreen} options={{ tabBarLabel: 'Home' }} />
      <Tabs.Screen
        name={ROUTES.Services}
        component={ServicesScreen}
        options={{ tabBarLabel: 'Services' }}
      />
      <Tabs.Screen
        name={ROUTES.Activity}
        component={ActivityScreen}
        options={{ tabBarLabel: 'Activity' }}
      />
      <Tabs.Screen
        name={ROUTES.Account}
        component={AccountScreen}
        options={{ tabBarLabel: 'Account' }}
      />
    </Tabs.Navigator>
  );
}

export default function RootNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Tabs" component={TabsNavigator} />
        <Stack.Screen name={ROUTES.Search} component={SearchScreen} />
        <Stack.Screen name={ROUTES.Booking} component={BookingScreen} />
        <Stack.Screen name={ROUTES.Tracking} component={TrackingScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  tabWrap: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 18,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: radii.pill,
    padding: 6,
    shadowColor: '#000',
    shadowOpacity: 0.14,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
    elevation: 10,
  },
  tabItem: { flex: 1, alignItems: 'center' },
  tabInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderRadius: radii.pill,
  },
  tabInnerActive: {
    backgroundColor: colors.primary,
    paddingHorizontal: 18,
  },
  tabLabel: { color: '#FFFFFF', fontWeight: '700', fontSize: 14, marginLeft: 6 },
});
