/**
 * Home — Uber-style.
 * Rhino/Parcel tabs, "Where to?" search pill, Recent places,
 * "For you" circular tile grid.
 */
import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radii } from '../theme';
import { ROUTES } from '../navigation';
import { getRecentPlaces } from '../lib/recent';
import { comingSoon } from '../lib/comingSoon';
import ForYouTile from '../components/ForYouTile';

const TILES = [
  { icon: 'car-sport', label: 'Auto' },
  { icon: 'storefront', label: 'Store pick-up' },
  { icon: 'car', label: 'Trip', badge: '25%', trip: true },
  { icon: 'bicycle', label: 'Bike Saver' },
  { icon: 'cube', label: 'Parcel', badge: '25%' },
  { icon: 'car-outline', label: 'Rentals' },
  { icon: 'person', label: 'Seniors' },
  { icon: 'people', label: 'Teens' },
];

export default function HomeScreen() {
  const navigation = useNavigation();
  const [tab, setTab] = useState('ride'); // 'ride' | 'parcel'
  const recent = getRecentPlaces();

  const openTrip = () => navigation.navigate(ROUTES.Booking, { presetDropoff: null });
  const goPlace = (place) => navigation.navigate(ROUTES.Booking, { presetDropoff: place });

  if (tab === 'parcel') {
    return (
      <View style={styles.container}>
        <View style={styles.topTabs}>
          <TouchableOpacity style={styles.topTab} onPress={() => setTab('ride')}>
            <Ionicons name="car" size={18} color={colors.text} />
            <Text style={styles.topTabText}>Rhino</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.topTab} onPress={() => setTab('parcel')}>
            <Ionicons name="bag-handle" size={18} color={colors.text} />
            <Text style={[styles.topTabText, styles.topTabTextActive]}>Parcel</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.parcelCard}>
          <Ionicons name="cube" size={44} color={colors.text} />
          <Text style={styles.parcelTitle}>Parcel delivery</Text>
          <Text style={styles.parcelSub}>Send and receive packages in minutes — coming soon!</Text>
          <TouchableOpacity style={styles.parcelBtn} onPress={() => comingSoon('Parcel')}>
            <Text style={styles.parcelBtnText}>Notify me</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Top tabs */}
        <View style={styles.topTabs}>
          <TouchableOpacity style={styles.topTab} onPress={() => setTab('ride')}>
            <Ionicons name="car" size={18} color={colors.text} />
            <Text style={[styles.topTabText, styles.topTabTextActive]}>Rhino</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.topTab} onPress={() => setTab('parcel')}>
            <Ionicons name="bag-handle" size={18} color={colors.text} />
            <Text style={styles.topTabText}>Parcel</Text>
          </TouchableOpacity>
        </View>

        {/* Search row */}
        <TouchableOpacity style={styles.searchRow} onPress={() => navigation.navigate(ROUTES.Search)}>
          <View style={styles.searchPill}>
            <Ionicons name="search" size={20} color={colors.text} />
            <Text style={styles.searchPlaceholder}>Where to?</Text>
          </View>
          <View style={styles.laterPill}>
            <Ionicons name="calendar-outline" size={16} color={colors.text} />
            <Text style={styles.laterText}>Later</Text>
          </View>
        </TouchableOpacity>

        {/* Recent places */}
        <View style={styles.recentCard}>
          {recent.map((p, i) => (
            <TouchableOpacity
              key={p.id}
              style={[styles.recentRow, i > 0 && styles.recentRowBorder]}
              onPress={() => goPlace(p)}
              activeOpacity={0.7}
            >
              <View style={styles.clockBox}>
                <Ionicons name="time-outline" size={18} color={colors.text} />
              </View>
              <View style={styles.recentBody}>
                <Text style={styles.recentTitle}>{p.title}</Text>
                <Text style={styles.recentSub} numberOfLines={1}>
                  {p.subtitle}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.muted} />
            </TouchableOpacity>
          ))}
        </View>

        {/* For you */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>For you</Text>
          <TouchableOpacity style={styles.sectionArrow} onPress={() => navigation.navigate(ROUTES.Services)}>
            <Ionicons name="arrow-forward" size={18} color={colors.text} />
          </TouchableOpacity>
        </View>
        <View style={styles.grid}>
          {TILES.map((t) => (
            <ForYouTile
              key={t.label}
              icon={t.icon}
              label={t.label}
              badge={t.badge}
              onPress={t.trip ? openTrip : () => comingSoon(t.label)}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20, paddingBottom: 120 },
  topTabs: { flexDirection: 'row', marginBottom: 16 },
  topTab: { flexDirection: 'row', alignItems: 'center', marginRight: 24, paddingBottom: 6 },
  topTabText: { fontSize: 17, fontWeight: '700', color: colors.muted, marginLeft: 6 },
  topTabTextActive: { color: colors.text, borderBottomWidth: 2, borderBottomColor: colors.text },
  searchRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 18 },
  searchPill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radii.pill,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginRight: 10,
  },
  searchPlaceholder: { fontSize: 15, color: colors.muted, marginLeft: 10 },
  laterPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radii.pill,
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  laterText: { fontSize: 14, fontWeight: '700', color: colors.text, marginLeft: 6 },
  recentCard: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.md,
    marginBottom: 24,
    paddingHorizontal: 14,
  },
  recentRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14 },
  recentRowBorder: { borderTopWidth: 1, borderTopColor: colors.border },
  clockBox: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  recentBody: { flex: 1 },
  recentTitle: { fontSize: 14, fontWeight: '700', color: colors.text },
  recentSub: { fontSize: 12, color: colors.muted, marginTop: 2 },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  sectionTitle: { fontSize: 20, fontWeight: '800', color: colors.text },
  sectionArrow: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  parcelCard: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  parcelTitle: { fontSize: 20, fontWeight: '800', color: colors.text, marginTop: 14 },
  parcelSub: { fontSize: 14, color: colors.muted, textAlign: 'center', marginTop: 8 },
  parcelBtn: {
    backgroundColor: colors.primary,
    borderRadius: radii.pill,
    paddingVertical: 13,
    paddingHorizontal: 26,
    marginTop: 18,
  },
  parcelBtnText: { color: '#FFFFFF', fontWeight: '700', fontSize: 14 },
});
