/**
 * Booking — map flow.
 * Pickup is auto-set from GPS (green pin). Tap the map to set/move the
 * drop-off (red pin). Live fare estimate + black "Request Rhino Trip" button.
 * Wires to the real backend via socket.io (rider:request -> ride:created).
 */
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radii } from '../theme';
import { ROUTES } from '../navigation';
import { connectSocket, fetchFares } from '../api';
import { resolveCurrentPosition } from '../lib/location';
import { reverseGeocode } from '../lib/geocode';
import { riderId } from '../lib/rider';
import { estimateDurationMin, formatDuration, formatMoney, haversineKm, midpoint } from '../geo';
import { DEFAULT_CITY, DEFAULT_DELTA } from '../constants';

export default function BookingScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const presetDropoff = route.params?.presetDropoff || null;

  const mapRef = useRef(null);
  const [pickup, setPickup] = useState(null);
  const [dropoff, setDropoff] = useState(
    presetDropoff ? { lat: presetDropoff.lat, lng: presetDropoff.lng } : null
  );
  const [pickupAddr, setPickupAddr] = useState(null);
  const [dropoffAddr, setDropoffAddr] = useState(presetDropoff ? presetDropoff.subtitle : null);
  const [fares, setFares] = useState(null);
  const [vehicleType, setVehicleType] = useState('ride');
  const [trip, setTrip] = useState(null); // { distanceKm, durationMin }
  const [locating, setLocating] = useState(true);
  const [requesting, setRequesting] = useState(false);

  const bothSet = !!(pickup && dropoff);

  /* Auto-set pickup from GPS on mount */
  useEffect(() => {
    (async () => {
      const pos = await resolveCurrentPosition();
      setPickup({ lat: pos.lat, lng: pos.lng });
      setLocating(false);
      const addr = await reverseGeocode(pos.lat, pos.lng);
      setPickupAddr(addr);
    })();
  }, []);

  /* Fare estimate whenever both points are set */
  useEffect(() => {
    if (!pickup || !dropoff) return undefined;
    const distanceKm = haversineKm(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng);
    const durationMin = estimateDurationMin(distanceKm);
    setTrip({ distanceKm, durationMin });
    let alive = true;
    fetchFares({ distanceKm, durationMin }).then((data) => {
      if (alive && data) setFares(data);
    });
    return () => {
      alive = false;
    };
  }, [pickup, dropoff]);

  /* Fit the map to both points */
  useEffect(() => {
    if (bothSet && mapRef.current) {
      try {
        mapRef.current.fitToCoordinates(
          [
            { latitude: pickup.lat, longitude: pickup.lng },
            { latitude: dropoff.lat, longitude: dropoff.lng },
          ],
          { edgePadding: { top: 150, right: 60, bottom: 430, left: 60 }, animated: true }
        );
      } catch (e) {
        /* ignore */
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bothSet]);

  function onMapPress(e) {
    const { latitude, longitude } = e.nativeEvent.coordinate;
    setDropoff({ lat: latitude, lng: longitude });
    reverseGeocode(latitude, longitude).then((a) => setDropoffAddr(a));
  }

  async function useMyLocation() {
    setLocating(true);
    const pos = await resolveCurrentPosition();
    setPickup({ lat: pos.lat, lng: pos.lng });
    setLocating(false);
    const addr = await reverseGeocode(pos.lat, pos.lng);
    setPickupAddr(addr);
  }

  function requestRide() {
    if (!bothSet || requesting) return;
    setRequesting(true);
    const socket = connectSocket();
    let responded = false;
    const finish = () => setRequesting(false);
    socket.emit('rider:request', {
      riderId,
      name: 'Rider',
      pickup,
      dropoff,
      vehicleType,
    });
    socket.once('ride:created', (data) => {
      responded = true;
      finish();
      navigation.replace(ROUTES.Tracking, {
        rideId: data.rideId,
        pickup,
        dropoff,
        vehicleType,
        fare: data.fare,
      });
    });
    socket.once('ride:error', (data) => {
      responded = true;
      finish();
      Alert.alert('Request failed', data.message || 'Something went wrong');
    });
    setTimeout(() => {
      if (!responded) {
        finish();
        Alert.alert('No response', 'The server did not answer. Is the backend running?');
      }
    }, 7000);
  }

  const selectedFare = fares && fares.find((f) => f.vehicleType === vehicleType);
  const region = {
    latitude: bothSet ? midpoint(pickup, dropoff).lat : DEFAULT_CITY.lat,
    longitude: bothSet ? midpoint(pickup, dropoff).lng : DEFAULT_CITY.lng,
    ...DEFAULT_DELTA,
  };

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        initialRegion={region}
        onPress={onMapPress}
        mapPadding={{ top: 130, right: 16, bottom: bothSet ? 380 : 220, left: 16 }}
        showsUserLocation
      >
        {pickup && (
          <Marker coordinate={{ latitude: pickup.lat, longitude: pickup.lng }} title="Pickup">
            <View style={styles.pickupDot} />
          </Marker>
        )}
        {dropoff && (
          <Marker coordinate={{ latitude: dropoff.lat, longitude: dropoff.lng }} title="Drop-off">
            <Ionicons name="location" size={34} color={colors.danger} />
          </Marker>
        )}
        {bothSet && (
          <Polyline
            coordinates={[
              { latitude: pickup.lat, longitude: pickup.lng },
              { latitude: dropoff.lat, longitude: dropoff.lng },
            ]}
            strokeColor="#0C0C0E"
            strokeWidth={3}
            lineDashPattern={[1, 6]}
          />
        )}
      </MapView>

      {/* Top bar */}
      <View style={styles.topBar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="arrow-back" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={styles.topTitle}>
          {bothSet ? 'Review your trip' : 'Set your drop-off'}
        </Text>
      </View>

      {/* Bottom sheet */}
      <View style={[styles.sheet, bothSet ? styles.sheetFull : styles.sheetShort]}>
        {locating ? (
          <View style={styles.centerBox}>
            <ActivityIndicator color={colors.text} />
            <Text style={styles.centerText}>Finding your location…</Text>
          </View>
        ) : !bothSet ? (
          <View>
            <View style={styles.instructionRow}>
              <Ionicons name="locate" size={22} color={colors.accent} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={styles.instructionTitle}>
                  {dropoff ? 'Tap to move your drop-off' : 'Tap the map to set your drop-off'}
                </Text>
                <Text style={styles.instructionSub}>
                  {pickupAddr || `${pickup.lat.toFixed(4)}, ${pickup.lng.toFixed(4)}`}
                </Text>
              </View>
            </View>
            <TouchableOpacity style={styles.locateBtn} onPress={useMyLocation}>
              <Text style={styles.locateText}>📡 Use my current location</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View>
            {/* Address card */}
            <View style={styles.addressCard}>
              <View style={styles.addressRow}>
                <View style={[styles.addressDot, { backgroundColor: colors.accent }]} />
                <Text style={styles.addressText} numberOfLines={1}>
                  {pickupAddr || `Pickup (${pickup.lat.toFixed(4)}, ${pickup.lng.toFixed(4)})`}
                </Text>
              </View>
              <View style={styles.addressRow}>
                <View style={[styles.addressDot, { backgroundColor: colors.danger }]} />
                <Text style={styles.addressText} numberOfLines={1}>
                  {dropoffAddr || `Drop-off (${dropoff.lat.toFixed(4)}, ${dropoff.lng.toFixed(4)})`}
                </Text>
              </View>
              <Text style={styles.tripMeta}>
                {trip.distanceKm.toFixed(1)} km • ~{formatDuration(trip.durationMin)}
              </Text>
            </View>

            {/* Vehicle selector */}
            {fares ? (
              <View style={styles.vehicleRow}>
                {fares.map((f) => (
                  <TouchableOpacity
                    key={f.vehicleType}
                    style={[styles.vehicleCard, vehicleType === f.vehicleType && styles.vehicleCardActive]}
                    onPress={() => setVehicleType(f.vehicleType)}
                  >
                    <Text style={styles.vehicleName}>{f.vehicleName}</Text>
                    <Text style={styles.vehicleSeats}>{f.seats} seats</Text>
                    <Text style={styles.vehiclePrice}>{formatMoney(f.total)}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            ) : (
              <View style={styles.centerBox}>
                <ActivityIndicator color={colors.text} />
                <Text style={styles.centerText}>Estimating fares…</Text>
              </View>
            )}

            {/* Request button */}
            <TouchableOpacity
              style={[styles.requestBtn, requesting && { opacity: 0.6 }]}
              onPress={requestRide}
              disabled={requesting}
            >
              {requesting ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                <Text style={styles.requestText}>
                  Request Rhino Trip{' '}
                  {selectedFare ? `• ${formatMoney(selectedFare.total)}` : ''}
                </Text>
              )}
            </TouchableOpacity>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  pickupDot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.accent,
    borderWidth: 3,
    borderColor: '#FFFFFF',
  },
  topBar: {
    position: 'absolute',
    top: 12,
    left: 16,
    right: 16,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bg,
    borderRadius: radii.pill,
    paddingVertical: 10,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 2 },
    elevation: 4,
  },
  backBtn: { marginRight: 12 },
  topTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.bg,
    borderTopLeftRadius: radii.lg,
    borderTopRightRadius: radii.lg,
    padding: 16,
    paddingBottom: 28,
    shadowColor: '#000',
    shadowOpacity: 0.12,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: -4 },
    elevation: 8,
  },
  sheetShort: { maxHeight: '30%' },
  sheetFull: { maxHeight: '58%' },
  centerBox: { alignItems: 'center', padding: 24 },
  centerText: { marginTop: 10, color: colors.muted, fontSize: 13 },
  instructionRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6 },
  instructionTitle: { fontSize: 16, fontWeight: '700', color: colors.text },
  instructionSub: { fontSize: 13, color: colors.muted, marginTop: 3 },
  locateBtn: {
    backgroundColor: colors.primary,
    borderRadius: radii.pill,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 14,
  },
  locateText: { color: '#FFFFFF', fontWeight: '700', fontSize: 15 },
  addressCard: {
    backgroundColor: colors.surface,
    borderRadius: radii.md,
    padding: 14,
    marginBottom: 12,
  },
  addressRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 3 },
  addressDot: { width: 10, height: 10, borderRadius: 5, marginRight: 10 },
  addressText: { flex: 1, fontSize: 13, color: colors.text },
  tripMeta: { fontSize: 12, color: colors.muted, marginTop: 6, marginLeft: 20 },
  vehicleRow: { flexDirection: 'row', gap: 8, marginBottom: 14 },
  vehicleCard: {
    flex: 1,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radii.md,
    padding: 12,
  },
  vehicleCardActive: { borderColor: colors.text, backgroundColor: colors.surface },
  vehicleName: { fontSize: 14, fontWeight: '800', color: colors.text },
  vehicleSeats: { fontSize: 11, color: colors.muted, marginTop: 2 },
  vehiclePrice: { fontSize: 14, fontWeight: '700', color: colors.text, marginTop: 6 },
  requestBtn: {
    backgroundColor: colors.primary,
    borderRadius: radii.pill,
    paddingVertical: 16,
    alignItems: 'center',
  },
  requestText: { color: '#FFFFFF', fontWeight: '800', fontSize: 16 },
});
