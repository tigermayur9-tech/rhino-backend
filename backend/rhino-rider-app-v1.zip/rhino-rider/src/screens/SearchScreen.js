/**
 * "Where to?" — search screen.
 * Autofocused input + saved places + promo cards + Explore row (visual).
 * Typing + search geocodes via OpenStreetMap; tapping a saved place goes
 * straight to Booking with that destination.
 */
import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radii } from '../theme';
import { ROUTES } from '../navigation';
import { geocode } from '../lib/geocode';
import { comingSoon } from '../lib/comingSoon';

const SAVED = [
  {
    id: 's1',
    icon: 'school',
    title: 'College',
    subtitle: 'San Francisco State University',
    lat: 37.7213,
    lng: -122.4785,
  },
  {
    id: 's2',
    icon: 'home',
    title: "granny's home",
    subtitle: 'Sunset District, San Francisco',
    lat: 37.7516,
    lng: -122.4916,
  },
  {
    id: 's3',
    icon: 'briefcase',
    title: 'Work',
    subtitle: 'Downtown, San Francisco',
    lat: 37.7936,
    lng: -122.3965,
  },
];

const EXPLORE = [
  { icon: 'bicycle', label: 'Bike Direct' },
  { icon: 'car-sport', label: 'Auto' },
  { icon: 'car', label: 'Cab Non AC' },
  { icon: 'car', label: 'Cab AC' },
];

export default function SearchScreen() {
  const navigation = useNavigation();
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);

  const goPlace = (p) =>
    navigation.navigate(ROUTES.Booking, {
      presetDropoff: { id: p.id, title: p.title, subtitle: p.subtitle, lat: p.lat, lng: p.lng },
    });

  async function goQuery() {
    const q = query.trim();
    if (!q) return;
    setSearching(true);
    const res = await geocode(q);
    setSearching(false);
    if (!res) {
      Alert.alert('Not found', `Couldn't find "${q}". Try a different name or address.`);
      return;
    }
    goPlace({ id: 'q', title: q, subtitle: res.label, lat: res.lat, lng: res.lng });
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} hitSlop={10} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <View style={styles.inputWrap}>
          <TextInput
            style={styles.input}
            placeholder="Where do you want to go?"
            placeholderTextColor={colors.muted}
            autoFocus
            value={query}
            onChangeText={setQuery}
            returnKeyType="search"
            onSubmitEditing={goQuery}
          />
          {searching ? (
            <ActivityIndicator size="small" color={colors.text} />
          ) : (
            <Ionicons name="search" size={20} color={colors.muted} />
          )}
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {/* Saved places */}
        {SAVED.map((p) => (
          <TouchableOpacity key={p.id} style={styles.placeRow} onPress={() => goPlace(p)} activeOpacity={0.7}>
            <View style={styles.placeIconBox}>
              <Ionicons name={p.icon} size={22} color={colors.text} />
            </View>
            <View style={styles.placeBody}>
              <Text style={styles.placeTitle}>{p.title}</Text>
              <Text style={styles.placeSub} numberOfLines={1}>
                {p.subtitle}
              </Text>
            </View>
            <Ionicons name="heart" size={22} color={colors.danger} />
          </TouchableOpacity>
        ))}

        {/* Everything in minutes */}
        <Text style={styles.sectionTitle}>Everything in minutes</Text>
        <View style={styles.promoRow}>
          <TouchableOpacity style={styles.promoWomen} onPress={() => comingSoon('For women rides')} activeOpacity={0.8}>
            <Text style={styles.promoWomenTitle}>For women</Text>
            <Text style={styles.promoWomenSub}>Bike rides, built for women</Text>
            <Ionicons name="bicycle" size={40} color="#FFFFFF" style={{ marginTop: 10 }} />
          </TouchableOpacity>
          <View style={styles.promoRight}>
            <TouchableOpacity style={styles.promoAuto} onPress={() => comingSoon('Book Auto Priority')} activeOpacity={0.8}>
              <View style={styles.newTag}>
                <Text style={styles.newTagText}>NEW</Text>
              </View>
              <Text style={styles.promoAutoTitle}>Book Auto Priority</Text>
              <Ionicons name="car-sport" size={28} color={colors.text} style={{ marginTop: 8 }} />
            </TouchableOpacity>
            <View style={styles.promoSmallRow}>
              <TouchableOpacity style={styles.promoSmall} onPress={() => comingSoon('Parcel')} activeOpacity={0.8}>
                <Text style={styles.promoSmallText}>Parcel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.promoSmall} onPress={() => comingSoon('More')} activeOpacity={0.8}>
                <Text style={styles.promoSmallText}>More</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Explore */}
        <View style={styles.exploreHeader}>
          <Text style={styles.sectionTitle}>Explore</Text>
          <TouchableOpacity onPress={() => comingSoon('View all')}>
            <Text style={styles.viewAll}>View All</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.exploreRow}>
          {EXPLORE.map((e) => (
            <TouchableOpacity key={e.label} style={styles.exploreTile} onPress={() => comingSoon(e.label)}>
              <View style={styles.exploreCircle}>
                <Ionicons name={e.icon} size={24} color={colors.text} />
              </View>
              <Text style={styles.exploreLabel}>{e.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 10,
  },
  backBtn: { marginRight: 10 },
  inputWrap: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radii.pill,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  input: { flex: 1, fontSize: 15, color: colors.text, padding: 0 },
  content: { paddingHorizontal: 20, paddingBottom: 40 },
  placeRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 13 },
  placeIconBox: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  placeBody: { flex: 1 },
  placeTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
  placeSub: { fontSize: 12, color: colors.muted, marginTop: 2 },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.text,
    marginTop: 22,
    marginBottom: 14,
  },
  promoRow: { flexDirection: 'row', gap: 12 },
  promoWomen: {
    flex: 1,
    backgroundColor: '#9C5BC9',
    borderRadius: radii.md,
    padding: 16,
  },
  promoWomenTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '800' },
  promoWomenSub: { color: 'rgba(255,255,255,0.85)', fontSize: 12, marginTop: 4 },
  promoRight: { flex: 1, gap: 12 },
  promoAuto: {
    backgroundColor: '#FFF3D6',
    borderRadius: radii.md,
    padding: 16,
    position: 'relative',
  },
  newTag: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: colors.blue,
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  newTagText: { color: '#FFFFFF', fontSize: 10, fontWeight: '800' },
  promoAutoTitle: { fontSize: 14, fontWeight: '800', color: colors.text, maxWidth: '80%' },
  promoSmallRow: { flexDirection: 'row', gap: 12 },
  promoSmall: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: radii.md,
    paddingVertical: 14,
    alignItems: 'center',
  },
  promoSmallText: { fontSize: 13, fontWeight: '700', color: colors.text },
  exploreHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  viewAll: { fontSize: 13, fontWeight: '700', color: colors.text },
  exploreRow: { flexDirection: 'row', justifyContent: 'space-between' },
  exploreTile: { alignItems: 'center', width: '23%' },
  exploreCircle: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  exploreLabel: { fontSize: 11, fontWeight: '600', color: colors.text, textAlign: 'center' },
});
