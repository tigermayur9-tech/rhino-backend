/**
 * Services — full service directory grid (Uber-style).
 * "Trip" is live (opens booking); everything else is coming soon.
 */
import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme';
import { ROUTES } from '../navigation';
import { comingSoon } from '../lib/comingSoon';
import ServiceCard from '../components/ServiceCard';

const CARDS = [
  { icon: 'car-sport', title: 'Auto', big: true },
  { icon: 'car', title: 'Trip', badge: '25%', big: true, trip: true },
  { icon: 'bicycle', title: 'Bike Saver' },
  { icon: 'car-outline', title: 'Rentals' },
  { icon: 'person', title: 'Seniors' },
  { icon: 'people', title: 'Teens' },
  { icon: 'calendar', title: 'Schedule', badge: '20%' },
  { icon: 'business', title: 'Intercity', badge: '12%' },
  { icon: 'bus', title: 'Bus & Train', badge: 'Promo' },
  { icon: 'train', title: 'Metro' },
];

const PARCEL_CARDS = [
  { icon: 'storefront', title: 'Store pick-up' },
  { icon: 'cube', title: 'Parcel', badge: '25%' },
];

export default function ServicesScreen() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Services</Text>
        <Text style={styles.subtitle}>Go anywhere, get anything</Text>

        <View style={styles.grid}>
          {CARDS.map((c) => (
            <ServiceCard
              key={c.title}
              icon={c.icon}
              title={c.title}
              badge={c.badge}
              wide={c.big}
              onPress={
                c.trip
                  ? () => navigation.navigate(ROUTES.Booking, { presetDropoff: null })
                  : () => comingSoon(c.title)
              }
            />
          ))}
        </View>

        <Text style={styles.sectionTitle}>Use Parcel to help</Text>
        <View style={styles.grid}>
          {PARCEL_CARDS.map((c) => (
            <ServiceCard
              key={c.title}
              icon={c.icon}
              title={c.title}
              badge={c.badge}
              wide
              onPress={() => comingSoon(c.title)}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20, paddingBottom: 120 },
  title: { fontSize: 28, fontWeight: '900', color: colors.text },
  subtitle: { fontSize: 14, color: colors.muted, marginTop: 4, marginBottom: 18 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.text,
    marginTop: 10,
    marginBottom: 14,
  },
});
