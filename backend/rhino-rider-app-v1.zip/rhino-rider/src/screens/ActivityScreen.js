/**
 * Activity — ride history.
 * Fetches real ride history from the backend (GET /api/riders/:riderId/rides).
 * Shows an empty state until rides exist.
 */
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radii } from '../theme';
import { fetchRideHistory } from '../api';
import { riderId } from '../lib/rider';
import { formatDate, formatMoney } from '../geo';
import { comingSoon } from '../lib/comingSoon';

const ACTIVE = ['requested', 'accepted', 'arriving', 'in_progress'];

function statusMeta(status, cancelReason) {
  if (ACTIVE.includes(status)) return { label: 'In progress', color: colors.blue };
  if (status === 'completed') return { label: 'Completed', color: colors.accent };
  return { label: cancelReason === 'rider_cancelled' ? 'Cancelled' : 'Cancelled', color: colors.danger };
}

export default function ActivityScreen() {
  const [rides, setRides] = useState(null); // null = loading

  useEffect(() => {
    let alive = true;
    fetchRideHistory(riderId).then((data) => {
      if (!alive) return;
      setRides(Array.isArray(data) ? data : []);
    });
    return () => {
      alive = false;
    };
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Ride History</Text>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Metro banner (visual) */}
        <TouchableOpacity style={styles.banner} onPress={() => comingSoon('Metro tickets')} activeOpacity={0.8}>
          <Ionicons name="train" size={28} color={colors.blue} />
          <Text style={styles.bannerText}>Check your metro tickets</Text>
          <Text style={styles.bannerLink}>View tickets</Text>
        </TouchableOpacity>

        <View style={styles.filterRow}>
          <TouchableOpacity style={styles.filterChip}>
            <Text style={styles.filterText}>All</Text>
          </TouchableOpacity>
        </View>

        {rides === null ? (
          <View style={styles.centerBox}>
            <ActivityIndicator color={colors.text} />
            <Text style={styles.centerText}>Loading your rides…</Text>
          </View>
        ) : rides.length === 0 ? (
          <View style={styles.centerBox}>
            <Ionicons name="car-outline" size={64} color={colors.border} />
            <Text style={styles.emptyTitle}>No rides yet</Text>
            <Text style={styles.centerText}>Your Rhino trips will show up here.</Text>
          </View>
        ) : (
          rides.map((r) => {
            const meta = statusMeta(r.status, r.cancelReason);
            return (
              <TouchableOpacity key={r.id} style={styles.rideRow} onPress={() => comingSoon('Ride details')} activeOpacity={0.7}>
                <View style={styles.rideIconBox}>
                  <Ionicons name="car-sport" size={22} color={colors.text} />
                </View>
                <View style={styles.rideBody}>
                  <Text style={styles.rideTitle} numberOfLines={1}>
                    {r.pickup ? `${r.pickup.lat.toFixed(4)}, ${r.pickup.lng.toFixed(4)}` : 'Rhino Trip'}
                  </Text>
                  <Text style={styles.rideSub}>{formatDate(r.timestamps && r.timestamps.requested)}</Text>
                  <Text style={styles.rideMeta}>
                    {formatMoney(r.fare && r.fare.total)}{' '}
                    <Text style={{ color: meta.color }}>• {meta.label}</Text>
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color={colors.muted} />
              </TouchableOpacity>
            );
          })
        )}

        {/* Older rides card (visual) */}
        <View style={styles.olderCard}>
          <View style={styles.olderIcon}>
            <Ionicons name="help-circle-outline" size={26} color={colors.text} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.olderTitle}>Looking for rides older than 90 days?</Text>
          </View>
          <TouchableOpacity style={styles.olderBtn} onPress={() => comingSoon('Request ride history')}>
            <Text style={styles.olderBtnText}>Request</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  title: { fontSize: 28, fontWeight: '900', color: colors.text, padding: 20, paddingBottom: 12 },
  content: { paddingHorizontal: 20, paddingBottom: 120 },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.md,
    padding: 14,
    marginBottom: 14,
  },
  bannerText: { flex: 1, fontSize: 14, fontWeight: '700', color: colors.text, marginLeft: 12 },
  bannerLink: { fontSize: 13, fontWeight: '700', color: colors.blue },
  filterRow: { flexDirection: 'row', marginBottom: 8 },
  filterChip: {
    backgroundColor: colors.surface,
    borderRadius: radii.pill,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  filterText: { fontSize: 13, fontWeight: '700', color: colors.text },
  centerBox: { alignItems: 'center', paddingVertical: 48 },
  centerText: { fontSize: 13, color: colors.muted, marginTop: 10 },
  emptyTitle: { fontSize: 17, fontWeight: '800', color: colors.text, marginTop: 12 },
  rideRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  rideIconBox: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  rideBody: { flex: 1 },
  rideTitle: { fontSize: 14, fontWeight: '700', color: colors.text },
  rideSub: { fontSize: 12, color: colors.muted, marginTop: 2 },
  rideMeta: { fontSize: 13, fontWeight: '700', color: colors.text, marginTop: 4 },
  olderCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radii.md,
    padding: 16,
    marginTop: 26,
  },
  olderIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  olderTitle: { fontSize: 13, fontWeight: '600', color: colors.text },
  olderBtn: {
    borderWidth: 1.5,
    borderColor: colors.text,
    borderRadius: radii.pill,
    paddingVertical: 8,
    paddingHorizontal: 14,
    marginLeft: 10,
  },
  olderBtnText: { fontSize: 12, fontWeight: '700', color: colors.text },
});
