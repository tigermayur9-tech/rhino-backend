/**
 * Account — profile + menu list (Uber-style).
 * Everything here is visual for now (coming soon on tap).
 */
import React from 'react';
import { Alert, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme';
import { comingSoon } from '../lib/comingSoon';

const MENU = [
  { icon: 'phone-portrait', title: 'Simple mode', badge: 'NEW', sub: 'A simplified app for easy use' },
  { icon: 'umbrella', title: 'Rider insurance' },
  { icon: 'gift', title: 'Send a gift' },
  { icon: 'people', title: 'People', sub: 'Manage all your contacts at Rhino' },
  { icon: 'car', title: 'Earn by driving or delivering', driver: true },
  { icon: 'bookmark', title: 'Saved groups', badge: 'NEW' },
  { icon: 'briefcase', title: 'Set up your business profile' },
  { icon: 'business', title: 'Rhino for Business' },
  { icon: 'megaphone', title: 'Refer friends, unlock deals' },
  { icon: 'settings', title: 'Manage account' },
];

export default function AccountScreen() {
  const onPressRow = (row) => {
    if (row.driver) {
      Alert.alert('Rhino Driver', 'The separate Rhino Driver app is coming soon!');
      return;
    }
    comingSoon(row.title);
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.name}>Rhino Rider</Text>
            <View style={styles.ratingPill}>
              <Text style={styles.ratingText}>★ 4.8</Text>
            </View>
          </View>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>🦏</Text>
          </View>
        </View>

        {/* Menu */}
        <View style={styles.menu}>
          {MENU.map((row, i) => (
            <TouchableOpacity
              key={row.title}
              style={[styles.row, i > 0 && styles.rowBorder]}
              onPress={() => onPressRow(row)}
              activeOpacity={0.7}
            >
              <View style={styles.rowIcon}>
                <Ionicons name={row.icon} size={22} color={colors.text} />
              </View>
              <View style={styles.rowBody}>
                <View style={styles.rowTitleLine}>
                  <Text style={styles.rowTitle}>{row.title}</Text>
                  {row.badge ? (
                    <View style={styles.newBadge}>
                      <Text style={styles.newBadgeText}>{row.badge}</Text>
                    </View>
                  ) : null}
                </View>
                {row.sub ? <Text style={styles.rowSub}>{row.sub}</Text> : null}
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.muted} />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20, paddingBottom: 120 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  name: { fontSize: 28, fontWeight: '900', color: colors.text },
  ratingPill: {
    alignSelf: 'flex-start',
    backgroundColor: colors.surface,
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginTop: 8,
  },
  ratingText: { fontSize: 14, fontWeight: '700', color: colors.text },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { fontSize: 32 },
  menu: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 16,
    paddingHorizontal: 16,
  },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 15 },
  rowBorder: { borderTopWidth: 1, borderTopColor: colors.border },
  rowIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  rowBody: { flex: 1 },
  rowTitleLine: { flexDirection: 'row', alignItems: 'center' },
  rowTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
  newBadge: {
    backgroundColor: colors.blue,
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginLeft: 8,
  },
  newBadgeText: { color: '#FFFFFF', fontSize: 10, fontWeight: '800' },
  rowSub: { fontSize: 12, color: colors.muted, marginTop: 2 },
});
