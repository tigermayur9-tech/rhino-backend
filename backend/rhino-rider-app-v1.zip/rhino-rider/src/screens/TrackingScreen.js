/**
 * Tracking — live ride status + driver marker.
 * Receives realtime updates via socket.io: ride:accepted,
 * driver:location_update, ride:arriving, ride:in_progress,
 * ride:completed, ride:cancelled.
 */
import React, { useEffect, useRef, useState } from 'react';
import { Alert, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radii } from '../theme';
import { connectSocket } from '../api';
import { useSocketEvents } from '../hooks/useSocketEvents';
import { addRecentPlace } from '../lib/recent';
import { formatMoney } from '../geo';

const STATUS_INFO = {
  requested: { icon: 'search', title: 'Looking for your driver…', sub: "We're finding the nearest Rhino nearby" },
  accepted: { icon: 'car', title: 'Driver is on the way', sub: 'Heading to your pickup point' },
  arriving: { icon: 'car', title: 'Driver is arriving', sub: "They're almost at your pickup point" },
  in_progress: { icon: 'navigate', title: 'Trip in progress', sub: 'Enjoy your ride!' },
  completed: { icon: 'checkmark-circle', title: 'Trip completed 🎉', sub: '' },
  cancelled: { icon: 'close-circle', title: 'Ride cancelled', sub: 'You can book another ride anytime' },
};

export default function TrackingScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const { rideId, pickup, dropoff, vehicleType, fare: initialFare } = route.params;

  const mapRef = useRef(null);
  const [status, setStatus] = useState('requested');
  const [driver, setDriver] = useState(null);
  const [driverPos, setDriverPos] = useState(null);
  const [etaMin, setEtaMin] = useState(null);
  const [fare, setFare] = useState(initialFare || null);
  const [rating, setRating] = useState(0);

  useSocketEvents({
    'ride:accepted': (data) => {
      setStatus('accepted');
      if (data.driver) {
        setDriver(data.driver);
        setDriverPos({ lat: data.driver.lat, lng: data.driver.lng });
      }
      setEtaMin(data.ride && data.ride.etaMin);
    },
    'driver:location_update': (data) => {
      if (data.rideId === rideId) setDriverPos({ lat: data.lat, lng: data.lng });
    },
    'ride:arriving': () => setStatus('arriving'),
    'ride:in_progress': () => setStatus('in_progress'),
    'ride:completed': (data) => {
      setStatus('completed');
      if (data.ride && data.ride.fare) setFare(data.ride.fare);
      if (dropoff) {
        addRecentPlace({
          id: `r-${rideId}`,
          title: 'Drop-off',
          subtitle: `Last drop-off (${dropoff.lat.toFixed(4)}, ${dropoff.lng.toFixed(4)})`,
          lat: dropoff.lat,
          lng: dropoff.lng,
        });
      }
    },
    'ride:cancelled': () => setStatus('cancelled'),
  });

  /* Fit map to pickup + dropoff + driver when they change */
  useEffect(() => {
    const coords = [
      { latitude: pickup.lat, longitude: pickup.lng },
      { latitude: dropoff.lat, longitude: dropoff.lng },
    ];
    if (driverPos) coords.push({ latitude: driverPos.lat, longitude: driverPos.lng });
    if (mapRef.current) {
      try {
        mapRef.current.fitToCoordinates(coords, {
          edgePadding: { top: 180, right: 70, bottom: 330, left: 70 },
          animated: true,
        });
      } catch (e) {
        /* ignore */
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [driverPos]);

  function cancelRide() {
    if (!['requested', 'accepted', 'arriving'].includes(status)) return;
    Alert.alert('Cancel this ride?', 'Your driver will be released.', [
      { text: 'Keep riding', style: 'cancel' },
      {
        text: 'Cancel ride',
        style: 'destructive',
        onPress: () => {
          connectSocket().emit('rider:cancel', { rideId });
          setStatus('cancelled');
        },
      },
    ]);
  }

  function submitRating() {
    if (rating > 0) connectSocket().emit('ride:rate', { rideId, rating });
    done();
  }

  function done() {
    navigation.popToTop();
  }

  const info = STATUS_INFO[status] || STATUS_INFO.requested;
  const canCancel = ['requested', 'accepted', 'arriving'].includes(status);
  const isDone = status === 'completed' || status === 'cancelled';

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        initialRegion={{
          latitude: pickup.lat,
          longitude: pickup.lng,
          latitudeDelta: 0.04,
          longitudeDelta: 0.04,
        }}
      >
        <Marker coordinate={{ latitude: pickup.lat, longitude: pickup.lng }} title="Pickup">
          <View style={styles.pickupDot} />
        </Marker>
        <Marker coordinate={{ latitude: dropoff.lat, longitude: dropoff.lng }} title="Drop-off">
          <Ionicons name="location" size={34} color={colors.danger} />
        </Marker>
        {driverPos && (
          <Marker coordinate={{ latitude: driverPos.lat, longitude: driverPos.lng }} title="Driver">
            <View style={styles.driverDot} />
          </Marker>
        )}
      </MapView>

      {/* Top bar */}
      <View style={styles.topBar}>
        <Text style={styles.topTitle}>{vehicleType === 'ride' ? 'Rhino Trip' : `${vehicleType} Trip`}</Text>
      </View>

      {/* Bottom panel */}
      <View style={styles.panel}>
        <View style={styles.statusRow}>
          <View style={styles.statusIcon}>
            <Ionicons name={info.icon} size={28} color="#FFFFFF" />
          </View>
          <View style={{ flex: 1, marginLeft: 14 }}>
            <Text style={styles.statusTitle}>{info.title}</Text>
            <Text style={styles.statusSub}>
              {status === 'accepted' && driver
                ? `${driver.name} • ${etaMin ? `Arriving in ~${etaMin} min` : 'Heading to your pickup'}`
                : info.sub}
            </Text>
          </View>
        </View>

        {isDone ? (
          <View>
            {status === 'completed' && (
              <View style={styles.rateWrap}>
                <Text style={styles.rateTitle}>Rate your driver</Text>
                <View style={styles.starsRow}>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <TouchableOpacity key={n} onPress={() => setRating(n)} hitSlop={6}>
                      <Ionicons
                        name={n <= rating ? 'star' : 'star-outline'}
                        size={34}
                        color={n <= rating ? '#FFB400' : colors.border}
                      />
                    </TouchableOpacity>
                  ))}
                </View>
                <Text style={styles.fareText}>
                  Fare: {formatMoney(fare ? fare.total : 0)}
                </Text>
              </View>
            )}
            <TouchableOpacity style={styles.doneBtn} onPress={rating > 0 ? submitRating : done}>
              <Text style={styles.doneText}>{status === 'completed' ? 'Done' : 'Back to Home'}</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <TouchableOpacity style={styles.cancelBtn} onPress={cancelRide} disabled={!canCancel}>
            <Text style={styles.cancelText}>Cancel ride</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  pickupDot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.accent,
    borderWidth: 3,
    borderColor: '#FFFFFF',
  },
  driverDot: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: '#1A6BFF',
    borderWidth: 3,
    borderColor: '#FFFFFF',
  },
  topBar: {
    position: 'absolute',
    top: 12,
    left: 16,
    right: 16,
    alignItems: 'center',
    backgroundColor: colors.bg,
    borderRadius: radii.pill,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 2 },
    elevation: 4,
  },
  topTitle: { fontSize: 15, fontWeight: '800', color: colors.text },
  panel: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.bg,
    borderTopLeftRadius: radii.lg,
    borderTopRightRadius: radii.lg,
    padding: 18,
    paddingBottom: 30,
    shadowColor: '#000',
    shadowOpacity: 0.12,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: -4 },
    elevation: 8,
  },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  statusIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusTitle: { fontSize: 17, fontWeight: '800', color: colors.text },
  statusSub: { fontSize: 13, color: colors.muted, marginTop: 3 },
  cancelBtn: {
    borderWidth: 1.5,
    borderColor: colors.text,
    borderRadius: radii.pill,
    paddingVertical: 14,
    alignItems: 'center',
  },
  cancelText: { fontSize: 15, fontWeight: '700', color: colors.text },
  rateWrap: { alignItems: 'center', marginBottom: 16 },
  rateTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 8 },
  starsRow: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  fareText: { fontSize: 14, fontWeight: '700', color: colors.text },
  doneBtn: {
    backgroundColor: colors.primary,
    borderRadius: radii.pill,
    paddingVertical: 15,
    alignItems: 'center',
  },
  doneText: { color: '#FFFFFF', fontWeight: '800', fontSize: 15 },
});
