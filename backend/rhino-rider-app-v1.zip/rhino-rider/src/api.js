/**
 * Backend connection (shared singleton).
 *
 * DEFAULT: your live backend on Render (works from anywhere in the world).
 * For local development only, override with an env var when starting Expo:
 *   EXPO_PUBLIC_API_URL=http://192.168.1.20:4000 npx expo start
 */
import { io } from 'socket.io-client';

export const BASE_URL =
  process.env.EXPO_PUBLIC_API_URL || 'https://rhino-backend-78xq.onrender.com';

let socket = null;

export function connectSocket() {
  if (!socket) {
    socket = io(BASE_URL, { transports: ['websocket', 'polling'] });
    socket.on('connect', () => console.log('[socket] connected', socket.id));
    socket.on('connect_error', (err) => console.warn('[socket] connect_error:', err.message));
    socket.on('disconnect', () => console.log('[socket] disconnected'));
  }
  if (!socket.connected) socket.connect();
  return socket;
}

export function getSocket() {
  return socket;
}

/** Fetch fares for a trip. Returns the fare array (or null on failure). */
export async function fetchFares({ distanceKm, durationMin }) {
  try {
    const res = await fetch(`${BASE_URL}/api/fare`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ distanceKm, durationMin }),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    console.warn('[api] fare fetch failed:', e.message);
    return null;
  }
}

/** Fetch ride history for a rider. */
export async function fetchRideHistory(riderId) {
  try {
    const res = await fetch(`${BASE_URL}/api/riders/${encodeURIComponent(riderId)}/rides`);
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    console.warn('[api] history fetch failed:', e.message);
    return null;
  }
}
