/** Demo city used when GPS is unavailable. Change to your own city! */
export const DEFAULT_CITY = { name: 'San Francisco', lat: 37.7749, lng: -122.4194 };

export const DEFAULT_DELTA = { latitudeDelta: 0.05, longitudeDelta: 0.05 };
