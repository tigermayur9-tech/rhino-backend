/**
 * Subscribe to socket events for the lifetime of a screen.
 * Automatically cleans up when the screen unmounts.
 */
import { useEffect } from 'react';
import { getSocket } from '../api';

export function useSocketEvents(handlers) {
  useEffect(() => {
    const socket = getSocket();
    if (!socket) return undefined;
    Object.entries(handlers).forEach(([event, fn]) => socket.on(event, fn));
    return () => Object.entries(handlers).forEach(([event, fn]) => socket.off(event, fn));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
