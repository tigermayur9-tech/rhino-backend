import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme';
import DiscountBadge from './DiscountBadge';

/** Circular icon tile with label + optional discount badge (Home "For you" grid). */
export default function ForYouTile({ icon, label, badge, onPress }) {
  return (
    <TouchableOpacity style={styles.tile} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.circle}>
        <Ionicons name={icon} size={26} color={colors.text} />
        {badge ? <DiscountBadge label={badge} style={styles.badge} /> : null}
      </View>
      <Text style={styles.label} numberOfLines={1}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  tile: { width: '25%', alignItems: 'center', marginBottom: 20 },
  circle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  badge: { position: 'absolute', top: -4, right: -6 },
  label: { fontSize: 12, fontWeight: '600', color: colors.text, marginTop: 8 },
});
