import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';

/** Small red discount/promo badge, e.g. "25%" or "Promo". */
export default function DiscountBadge({ label, style }) {
  return (
    <View style={[styles.badge, style]}>
      <Text style={styles.text}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    backgroundColor: colors.danger,
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  text: { color: '#FFFFFF', fontSize: 10, fontWeight: '800' },
});
