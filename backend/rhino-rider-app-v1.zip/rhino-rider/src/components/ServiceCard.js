import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radii } from '../theme';
import DiscountBadge from './DiscountBadge';

/** Gray rounded card for the Services grid. `wide` = full-width card. */
export default function ServiceCard({ icon, title, badge, onPress, wide }) {
  return (
    <TouchableOpacity
      style={[styles.card, wide ? styles.wide : styles.half]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.iconBox}>
        <Ionicons name={icon} size={wide ? 30 : 24} color={colors.text} />
        {badge ? <DiscountBadge label={badge} style={styles.badge} /> : null}
      </View>
      <Text style={[styles.title, wide && styles.titleWide]}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radii.md,
    padding: 16,
    justifyContent: 'space-between',
  },
  half: { width: '48%', minHeight: 108, marginBottom: 12 },
  wide: { width: '100%', minHeight: 92, flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  iconBox: { position: 'relative', alignSelf: 'flex-start' },
  badge: { position: 'absolute', top: -6, right: -14 },
  title: { fontSize: 14, fontWeight: '700', color: colors.text, marginTop: 10 },
  titleWide: { marginTop: 0, marginLeft: 14, flex: 1 },
});
