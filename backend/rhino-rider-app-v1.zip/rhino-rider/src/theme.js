/** Rhino Rider — colors + style tokens (Uber-style: black on white, red badges). */
export const colors = {
  bg: '#FFFFFF',
  surface: '#F6F6F6',
  border: '#E4E4E4',
  text: '#0C0C0E',
  muted: '#6B6B6F',
  primary: '#0C0C0E', // black pills/buttons
  accent: '#06C167', // green — pickup / positive
  accentSoft: '#E7F9EF',
  danger: '#E02020', // red badges / cancel
  blue: '#1877F2', // "NEW" badges / links
  tabInactive: '#8A8A8E',
};

export const radii = { sm: 10, md: 14, lg: 20, pill: 999 };
