# 🚀 Rhino — Production & Store Launch Checklist

This is the exact path from "working prototype on my laptop" to "live on the
Play Store & App Store". Do the steps in order. No coding required — just
copy-paste commands.

---

## STEP 1 — Put the backend online (required!)

The app currently talks to `localhost:4000` (your laptop). Store reviewers and
real users can't reach your laptop, so the backend must live on the internet.

**Easiest option: Render (free tier, ~10 minutes)**

1. Create a free account at https://render.com (sign in with GitHub).
2. Go to your GitHub account and create a **new public repository** (no README).
3. Upload the `backend` folder into it. Easiest way: on the repo page click
   **Add file → Upload files**, drag the contents of `ridehail-app/backend`
   (server.js, package.json, src/, scripts/) into it, then **Commit**.
4. Back on Render: **New → Web Service** → connect your GitHub repo.
5. Settings to use:
   - **Build command:** `npm install`
   - **Start command:** `npm start`
   - Plan: **Free**
6. Click **Create Web Service**. Wait ~3 minutes until it says "Live".
7. Copy your service URL, e.g. `https://rhino-backend-78xq.onrender.com`
   — check it works: open `<your-url>/health` in a browser, you should see
   `{"ok":true,...}`.

> Alternative hosts (same idea): Railway.app, Fly.io — pick whichever feels easiest.

---

## STEP 2 — Point the app at the online backend

Open `mobile/src/lib/api.js` and change the base URL to your live backend:

```js
export const BASE_URL = "https://rhino-backend-78xq.onrender.com";
```

(Or keep the env-var line and set `EXPO_PUBLIC_API_URL` at build time — see Step 4.)

---

## STEP 3 — Set your real app ID (do this BEFORE building)

Open `mobile/app.json` and replace the placeholder:

```json
"android": { "package": "com.yourcompany.rhino" },
"ios":     { "bundleIdentifier": "com.yourcompany.rhino" }
```

Use something unique, like `com.<yourname>.rhino`. **This cannot be changed
after your first store release**, so decide now.

---

## STEP 4 — Build the store files with EAS Build (cloud, no emulator)

Run these three commands in the `mobile` folder (from your laptop — the
building happens in Expo's cloud, so the emulator/firewall never matters):

```bash
npm install -g eas-cli     # once
eas login                  # create a free Expo account (expo.dev)
eas build:configure
eas build -p android --profile production    # → produces .aab  (Google Play)
eas build -p ios --profile production        # → produces .ipa  (Apple)
```

If you used the env-var approach in Step 2, tell EAS the URL at build time:

```bash
EXPO_PUBLIC_API_URL=https://rhino-backend-78xq.onrender.com eas build -p android --profile production
```

Each build takes ~10–20 min and finishes with a download link.

> iOS note: you must be enrolled in the Apple Developer Program ($99/year)
> before the iOS build can produce a store-ready `.ipa`.

---

## STEP 5 — Create the store accounts (only you can do this)

| Store | What to do | Cost |
|---|---|---|
| **Google Play** | https://play.google.com/console → create developer account → pay $25 once | $25 one-time |
| **Apple** | https://developer.apple.com → enroll in Apple Developer Program | $99/year |

---

## STEP 6 — Upload & submit

**Google Play:**
1. Play Console → **Create app** → fill name (Rhino), category **Travel & Local**.
2. Upload the `.aab` under **App releases**.
3. Complete the store listing: description (use `store-listing.md`),
   icon (use `mobile/assets/icon.png`), screenshots, content rating form.
4. Add your **privacy policy URL** (host `privacy-policy.md` anywhere — GitHub
   Pages, a free site, or Render).
5. **Submit for review** → usually 1–3 days.

**Apple App Store:**
1. App Store Connect → **My Apps → +** → fill in the listing.
2. Upload the `.ipa` with Transporter (free Mac app) or `eas submit -p ios`.
3. Category **Travel**, add screenshots, privacy policy URL, export compliance.
4. **Submit for review** → usually 1–3 days.

---

## ✅ Launch checklist summary

- [ ] Backend live (Step 1) — test `<url>/health` in a browser
- [ ] `mobile/src/lib/api.js` points to the live URL (Step 2)
- [ ] Real app ID in `app.json` (Step 3)
- [ ] `.aab` and `.ipa` built with EAS (Step 4)
- [ ] Google & Apple developer accounts (Step 5)
- [ ] Listing filled in + icon + screenshots (Step 6)
- [ ] Privacy policy hosted at a URL (Step 6)
- [ ] Submitted to both stores 🎉

---

## ⚠️ Important: before real users (phase 2)

This version is a functional MVP. To grow beyond friends/family testing, the
next build should add:
1. **User accounts** (email/phone login) — Firebase Auth or Clerk
2. **A real database** (PostgreSQL) — rides currently reset on server restart
3. **Payments** (Stripe or Razorpay)
4. **Driver KYC/verification** (Checkr, Persona)
5. **Push notifications** (Expo Notifications)

All of these are normal next steps — ask me and I'll build them into the code.
