# 🦏 Rhino — an Uber-style ride-hailing app

A real, working starter codebase for an Uber-like app, built with:

- **Mobile app** — Expo / React Native (one codebase for iOS + Android)
  - Rider side: tap the map to set pickup/drop-off → see live fare estimates for 3 vehicle types → request → watch your driver approach on a live map → ride → pay + rate
  - Driver side: set up your car → go online → get ride requests (accept/decline) → walk through the trip (arrived → started → completed) → track earnings
- **Backend** — Node.js / Express + Socket.io
  - Nearest-driver matching engine (retries until a driver accepts, keeps looking when none are online)
  - Fare pricing engine (base + distance + time + service fee)
  - Full ride lifecycle: `requested → accepted → arriving → in_progress → completed`
  - Live driver location broadcasts to the rider's map

---

## 📁 Project structure

```
ridehail-app/
├── backend/                 # the "brain" (Node.js server)
│   ├── server.js            # entry point
│   ├── src/
│   │   ├── sockets.js       # all realtime events
│   │   ├── matching.js      # nearest-driver matching engine
│   │   ├── fares.js         # pricing engine
│   │   ├── rides.js         # ride lifecycle
│   │   ├── store.js         # in-memory data (swap for a DB later)
│   │   └── geo.js           # distance/duration helpers
│   └── scripts/
│       └── simulate-ride.js # auto-test: a full ride without any phones
└── mobile/                  # the app (Expo / React Native)
    ├── App.js
    └── src/
        ├── screens/         # Role, RiderHome, RiderRide, DriverHome, DriverRequest, DriverRide
        ├── components/      # FareCard, Stars
        ├── lib/             # api (socket), location, geocode
        └── ...              # theme, geo helpers, tiny navigator
```

---

## ✅ What you need (free)

1. **A computer** with [Node.js 18+](https://nodejs.org) installed
2. **A phone** with the free **Expo Go** app
   - Android: [Google Play — Expo Go](https://play.google.com/store/apps/details?id=host.exp.exponent)
   - iPhone: [App Store — Expo Go](https://apps.apple.com/app/expo-go/id982107779)

> Two phones (or one phone + one Android emulator) let you test the full flow: one as driver, one as rider.

---

## 🚀 Run it (step by step, no coding needed)

### Step 1 — Start the backend
```bash
cd ridehail-app/backend
npm install
npm start
```
You should see: `🦏 Rhino backend running on http://localhost:4000`
Keep this terminal window open.

### Step 2 — Start the app
In a **second terminal window**:
```bash
cd ridehail-app/mobile
npm install
npx expo start
```
A QR code appears. Scan it with your phone's camera (iPhone) or inside the Expo Go app (Android).

### Step 3 — Connect the phone to the backend
The app needs to reach your backend on port 4000.

- **Android emulator / iOS simulator on the same computer:** nothing to do — it uses `localhost` / `10.0.2.2` automatically.
- **Physical phone (same Wi-Fi):** restart the app with your computer's LAN IP:
  ```bash
  EXPO_PUBLIC_API_URL=http://192.168.1.20:4000 npx expo start
  ```
  (Find your IP with `ipconfig` on Windows or `ifconfig` / `ip addr` on Mac/Linux. Your phone and computer must be on the same Wi-Fi.)

### Step 4 — Test it (the fun part)
1. **Phone A (driver):** open the app → **Drive & earn** → fill in your car → **Go online**.
2. **Phone B (rider):** open the app → **Book a ride** → tap the map for pickup → tap again for drop-off → pick a vehicle → **Request**.
3. Watch: the driver gets a request popup with the fare → accepts → the rider sees the driver's car approach on the map → the driver taps **Arrived → Start trip → Complete trip** → the rider sees the receipt and rates the driver.

### No phones handy? Test the whole thing automatically:
```bash
cd ridehail-app/backend
npm run simulate
```
This fakes a driver and a rider and runs a complete ride (request → match → accept → arrive → start → complete) with live logs.

---

## 🧪 Also try

- **No driver nearby:** request a ride with no driver online → the rider sees "No drivers nearby…" → go online as a driver → they get matched automatically.
- **Decline a request:** as a driver, decline → the backend tries the next-nearest driver.
- **Cancel mid-ride:** the rider can cancel before pickup; the driver gets notified and is freed up.
- **Multiple vehicle types:** Ride / Comfort / XL have different pricing — tune the rates in `backend/src/fares.js`.

---

## 📊 What's already built in

| Feature | Where |
|---|---|
| Interactive map, tap-to-set pickup/drop-off | `mobile/src/screens/RiderHomeScreen.js` |
| Free reverse geocoding (addresses, no API key) | `mobile/src/lib/geocode.js` |
| Live fare estimates + receipt breakdown | `backend/src/fares.js` |
| Nearest-driver matching with retry + fallback | `backend/src/matching.js` |
| Live driver marker on rider map | `backend/src/sockets.js` |
| Full ride lifecycle + cancellation handling | `backend/src/rides.js` |
| Driver stats (trips, earnings) | `mobile/src/screens/DriverHomeScreen.js` |
| 5-star rating after each trip | `mobile/src/components/Stars.js` |

---

## ⚠️ What's NOT built yet (before real users)

This is an **MVP prototype**, not a production app. Before launching you'll want:

1. **Real accounts** — email/phone login + verification (e.g. Firebase Auth, Clerk)
2. **A real database** — rides/drivers currently live in memory and reset when the server restarts (PostgreSQL + Redis)
3. **Real payments** — Stripe / PayPal / local methods, driver payouts, receipts by email
4. **Driver onboarding/KYC** — document upload, background checks
5. **Real GPS + routing** — Google Maps API keys (the map currently uses Apple/Google default tiles and simulated movement)
6. **Admin dashboard** — users, rides, disputes, analytics
7. **Safety features** — SOS button, trip sharing, rider verification
8. **Deploy the backend publicly** — e.g. Render, Railway, or Fly.io (the phone needs to reach the server from anywhere)

---

## 📱 Publishing to the Play Store & App Store (the roadmap)

**The 30,000-ft view:** `npx expo start` is for development. To ship, you build a release package with **EAS Build**, then upload it to each store. Here's the path:

1. **Create a [Google Play Developer account](https://play.google.com/console/about/)** — **$25 one-time**. Create an **Apple Developer account** — **$99/year**.
2. **Install EAS CLI:** `npm install -g eas-cli`, then `eas login` and `eas build:configure` (inside `mobile/`).
3. **Set your app ID** in `mobile/app.json`:
   - `android.package` → `com.yourcompany.rhino` (unique to you)
   - `ios.bundleIdentifier` → same value
4. **Build for the stores** (no Xcode/Android Studio needed — cloud builds):
   - `eas build -p android --profile production` → produces an **.aab** file
   - `eas build -p ios --profile production` → produces an **.ipa** file
5. **Upload:**
   - Play Store: sign in to Play Console → *Create app* → upload the `.aab` → fill in store listing (I can write your description/keywords) → submit for review.
   - App Store: upload the `.ipa` (via Transporter or Xcode) → App Store Connect → fill in listing + screenshots → submit for review.
6. **Before you build**, make sure the backend is deployed publicly (step 8 above) and the app points to it via `EXPO_PUBLIC_API_URL`.

> Store review can take a few days. You'll also need: app icon (1024×1024), screenshots (6.7" and 5.5"), a privacy policy URL. I can prepare all of these for you when you're ready.

---

## 🔧 Troubleshooting

| Problem | Fix |
|---|---|
| App can't reach the server | Physical phone: use `EXPO_PUBLIC_API_URL=http://<your-LAN-IP>:4000`. Same Wi-Fi required. |
| Port 4000 already in use | `PORT=4001 npm start` (backend) and restart the app with the new port. |
| Map is blank | In Expo Go this works out of the box. For standalone builds you'll need Google Maps API keys. |
| Location permission denied | The app falls back to the demo city (San Francisco) so it still works. |
| Backend logs look empty | Check the terminal where you ran `npm start` — all ride events are logged there. |

---

Happy testing! 🚀
