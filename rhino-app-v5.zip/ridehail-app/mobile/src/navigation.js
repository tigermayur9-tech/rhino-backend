/**
 * Tiny state-based navigator (no extra dependencies).
 * Screens: Role, RiderHome, RiderRide, DriverHome, DriverRequest, DriverRide
 */
import React, { createContext, useContext, useState } from 'react';

export const SCREENS = {
  Role: 'Role',
  RiderHome: 'RiderHome',
  RiderRide: 'RiderRide',
  DriverHome: 'DriverHome',
  DriverRequest: 'DriverRequest',
  DriverRide: 'DriverRide',
};

const NavContext = createContext(null);

export function NavigationProvider({ children }) {
  const [route, setRoute] = useState({ name: SCREENS.Role, params: {} });

  const navigate = (name, params = {}) => setRoute({ name, params });
  const goBack = () => setRoute({ name: SCREENS.Role, params: {} });

  return (
    <NavContext.Provider value={{ route, navigate, goBack }}>{children}</NavContext.Provider>
  );
}

export function useNav() {
  return useContext(NavContext);
}
