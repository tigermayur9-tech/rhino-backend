/** App colors + style tokens. */
export const colors = {
  bg: '#FFFFFF',
  surface: '#F6F6F6',
  border: '#E4E4E4',
  text: '#0C0C0E',
  muted: '#6B6B6F',
  primary: '#0C0C0E',
  accent: '#06C167',
  accentSoft: '#E7F9EF',
  danger: '#E02020',
};

export const radii = { sm: 10, md: 14, lg: 22, pill: 999 };
