/**
 * Rider home: interactive map.
 * 1) Tap the map to set pickup, 2) tap again to set drop-off,
 * 3) pick a vehicle type, 4) request the ride.
 */
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import { connectSocket, BASE_URL } from '../lib/api';
import { getCurrentPosition } from '../lib/location';
import { reverseGeocode } from '../lib/geocode';
import { estimateDurationMin, formatDuration, formatMoney, haversineKm, midpoint } from '../geo';
import { DEFAULT_CITY, DEFAULT_DELTA } from '../constants';
import { colors, radii } from '../theme';
import { SCREENS, useNav } from '../navigation';
import FareCard from '../components/FareCard';

const riderId = 'R' + Math.random().toString(36).slice(2, 10); // stable for this app session

export default function RiderHomeScreen() {
  const { navigate } = useNav();
  const mapRef = useRef(null);
  const [mode, setMode] = useState('pickup'); // 'pickup' | 'dropoff'
  const [pickup, setPickup] = useState(null);
  const [dropoff, setDropoff] = useState(null);
  const [addresses, setAddresses] = useState({ pickup: null, dropoff: null });
  const [fares, setFares] = useState(null);
  const [faresLoading, setFaresLoading] = useState(false);
  const [selectedType, setSelectedType] = useState('ride');
  const [requesting, setRequesting] = useState(false);
  const [locating, setLocating] = useState(false);

  const bothSet = !!(pickup && dropoff);

  /* Fetch fares + addresses whenever both points are set */
  useEffect(() => {
    if (!bothSet) return undefined;
    let cancelled = false;
    (async () => {
      const [pAddr, dAddr] = await Promise.all([
        reverseGeocode(pickup.lat, pickup.lng),
        reverseGeocode(dropoff.lat, dropoff.lng),
      ]);
      if (!cancelled) setAddresses({ pickup: pAddr, dropoff: dAddr });
    })();
    fetchFares();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bothSet]);

  /* Fit the map to both points */
  useEffect(() => {
    if (bothSet && mapRef.current) {
      try {
        mapRef.current.fitToCoordinates([pickup, dropoff], {
          edgePadding: { top: 170, right: 60, bottom: 430, left: 60 },
          animated: true,
        });
      } catch (e) {
        /* ignore */
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bothSet]);

  async function fetchFares() {
    const distanceKm = haversineKm(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng);
    const durationMin = estimateDurationMin(distanceKm);
    setFaresLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/fare`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ distanceKm, durationMin }),
      });
      const data = await res.json();
      if (Array.isArray(data)) setFares(data);
    } catch (e) {
      Alert.alert(
        'Server unreachable',
        `Make sure the backend is running and reachable at:\n${BASE_URL}`
      );
    }
    setFaresLoading(false);
  }

  function handleMapPress(e) {
    const { latitude, longitude } = e.nativeEvent.coordinate;
    if (mode === 'pickup') {
      setPickup({ lat: latitude, lng: longitude });
      setMode('dropoff');
    } else {
      setDropoff({ lat: latitude, lng: longitude });
      setMode('pickup');
    }
  }

  async function useMyLocation() {
    setLocating(true);
    const pos = await getCurrentPosition();
    setPickup(pos || { lat: DEFAULT_CITY.lat, lng: DEFAULT_CITY.lng });
    setMode('dropoff');
    setLocating(false);
  }

  function requestRide() {
    if (!bothSet || requesting) return;
    setRequesting(true);
    const socket = connectSocket();
    let responded = false;
    const finish = () => setRequesting(false);
    socket.emit('rider:request', {
      riderId,
      name: 'Rider',
      pickup,
      dropoff,
      vehicleType: selectedType,
    });
    socket.once('ride:created', (data) => {
      responded = true;
      finish();
      navigate(SCREENS.RiderRide, {
        rideId: data.rideId,
        pickup,
        dropoff,
        vehicleType: selectedType,
        fare: data.fare,
      });
    });
    socket.once('ride:error', (data) => {
      responded = true;
      finish();
      Alert.alert('Request failed', data.message || 'Something went wrong');
    });
    setTimeout(() => {
      if (!responded) {
        finish();
        Alert.alert('No response', 'The server did not answer. Is the backend running?');
      }
    }, 7000);
  }

  function clearAll() {
    setPickup(null);
    setDropoff(null);
    setFares(null);
    setAddresses({ pickup: null, dropoff: null });
    setMode('pickup');
  }

  const region = {
    latitude: bothSet ? midpoint(pickup, dropoff).lat : DEFAULT_CITY.lat,
    longitude: bothSet ? midpoint(pickup, dropoff).lng : DEFAULT_CITY.lng,
    ...DEFAULT_DELTA,
  };

  const distanceKm = bothSet
    ? haversineKm(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng)
    : 0;
  const durationMin = bothSet ? estimateDurationMin(distanceKm) : 0;
  const selectedFare = fares && fares.find((f) => f.vehicleType === selectedType);

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        initialRegion={region}
        onPress={handleMapPress}
        mapPadding={{ top: 140, right: 16, bottom: bothSet ? 460 : 250, left: 16 }}
        showsUserLocation
      >
        {pickup && (
          <Marker coordinate={{ latitude: pickup.lat, longitude: pickup.lng }} title="Pickup">
            <View style={[styles.dot, { backgroundColor: colors.accent }]} />
          </Marker>
        )}
        {dropoff && (
          <Marker coordinate={{ latitude: dropoff.lat, longitude: dropoff.lng }} title="Drop-off">
            <Text style={styles.pin}>📍</Text>
          </Marker>
        )}
        {bothSet && (
          <Polyline
            coordinates={[pickup, dropoff]}
            strokeColor="#0C0C0E"
            strokeWidth={4}
            lineDashPattern={[1, 6]}
          />
        )}
      </MapView>

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>
          {mode === 'pickup' ? 'Set your pickup point' : 'Set your drop-off point'}
        </Text>
        {bothSet && (
          <TouchableOpacity onPress={clearAll} hitSlop={8}>
            <Text style={styles.clear}>Clear</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Bottom panel */}
      <View style={[styles.panel, bothSet ? styles.panelFull : styles.panelShort]}>
        {!bothSet ? (
          <View>
            <View style={styles.instructionRow}>
              <Text style={styles.instructionEmoji}>
                {mode === 'pickup' ? '🟢' : '🔴'}
              </Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.instructionTitle}>
                  {mode === 'pickup' ? 'Tap the map to set pickup' : 'Tap the map to set drop-off'}
                </Text>
                <Text style={styles.instructionSub}>
                  {mode === 'pickup'
                    ? 'Choose where the driver should meet you'
                    : 'Now choose your destination'}
                </Text>
              </View>
            </View>
            {mode === 'pickup' && (
              <TouchableOpacity
                style={styles.locateBtn}
                onPress={useMyLocation}
                disabled={locating}
              >
                {locating ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text style={styles.locateText}>📡 Use my current location</Text>
                )}
              </TouchableOpacity>
            )}
          </View>
        ) : (
          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Route summary */}
            <View style={styles.addressCard}>
              <View style={styles.addressRow}>
                <View style={[styles.addressDot, { backgroundColor: colors.accent }]} />
                <Text style={styles.addressText} numberOfLines={2}>
                  {addresses.pickup || `Pickup (${pickup.lat.toFixed(4)}, ${pickup.lng.toFixed(4)})`}
                </Text>
              </View>
              <View style={styles.addressRow}>
                <View style={[styles.addressDot, { backgroundColor: colors.danger }]} />
                <Text style={styles.addressText} numberOfLines={2}>
                  {addresses.dropoff ||
                    `Drop-off (${dropoff.lat.toFixed(4)}, ${dropoff.lng.toFixed(4)})`}
                </Text>
              </View>
              <Text style={styles.tripMeta}>
                {distanceKm.toFixed(1)} km • ~{formatDuration(durationMin)}
              </Text>
            </View>

            {faresLoading && !fares ? (
              <View style={styles.loadingWrap}>
                <ActivityIndicator color={colors.accent} />
                <Text style={styles.loadingText}>Estimating fares…</Text>
              </View>
            ) : (
              <View>
                {fares &&
                  fares.map((f) => (
                    <FareCard
                      key={f.vehicleType}
                      fare={f}
                      selected={selectedType === f.vehicleType}
                      onPress={() => setSelectedType(f.vehicleType)}
                    />
                  ))}
                <TouchableOpacity
                  style={[styles.requestBtn, requesting && { opacity: 0.6 }]}
                  onPress={requestRide}
                  disabled={requesting}
                >
                  {requesting ? (
                    <ActivityIndicator color="#FFFFFF" />
                  ) : (
                    <Text style={styles.requestText}>
                      Request {selectedFare ? selectedFare.vehicleName : 'ride'} •{' '}
                      {selectedFare ? formatMoney(selectedFare.total) : ''}
                    </Text>
                  )}
                </TouchableOpacity>
              </View>
            )}
          </ScrollView>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    position: 'absolute',
    top: 8,
    left: 16,
    right: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.bg,
    borderRadius: radii.pill,
    paddingHorizontal: 18,
    paddingVertical: 14,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 2 },
    elevation: 4,
  },
  headerTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
  clear: { fontSize: 14, fontWeight: '700', color: colors.danger },
  panel: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.bg,
    borderTopLeftRadius: radii.lg,
    borderTopRightRadius: radii.lg,
    padding: 16,
    paddingBottom: 28,
    shadowColor: '#000',
    shadowOpacity: 0.12,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: -4 },
    elevation: 8,
  },
  panelShort: { maxHeight: '36%' },
  panelFull: { maxHeight: '72%' },
  instructionRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6 },
  instructionEmoji: { fontSize: 26, marginRight: 12 },
  instructionTitle: { fontSize: 16, fontWeight: '700', color: colors.text },
  instructionSub: { fontSize: 13, color: colors.muted, marginTop: 3 },
  locateBtn: {
    backgroundColor: colors.primary,
    borderRadius: radii.pill,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 14,
  },
  locateText: { color: '#FFFFFF', fontWeight: '700', fontSize: 15 },
  addressCard: {
    backgroundColor: colors.surface,
    borderRadius: radii.md,
    padding: 14,
    marginBottom: 12,
  },
  addressRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 3 },
  addressDot: { width: 10, height: 10, borderRadius: 5, marginRight: 10 },
  addressText: { flex: 1, fontSize: 13, color: colors.text },
  tripMeta: { fontSize: 12, color: colors.muted, marginTop: 6, marginLeft: 20 },
  loadingWrap: { alignItems: 'center', padding: 22 },
  loadingText: { marginTop: 10, color: colors.muted, fontSize: 13 },
  requestBtn: {
    backgroundColor: colors.accent,
    borderRadius: radii.pill,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 4,
  },
  requestText: { color: '#FFFFFF', fontWeight: '800', fontSize: 16 },
  dot: { width: 18, height: 18, borderRadius: 9, borderWidth: 3, borderColor: '#FFFFFF' },
  pin: { fontSize: 26 },
});
