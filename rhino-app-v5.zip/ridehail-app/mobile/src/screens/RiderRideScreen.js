/**
 * Rider live-trip screen: watch your driver approach, ride, then pay + rate.
 */
import React, { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import { getSocket } from '../lib/api';
import { formatMoney, midpoint } from '../geo';
import { DEFAULT_CITY, DEFAULT_DELTA } from '../constants';
import { colors, radii } from '../theme';
import { SCREENS, useNav } from '../navigation';
import { useSocketEvents } from '../hooks/useSocketEvents';
import Stars from '../components/Stars';

const STATUS_LABELS = {
  requested: 'Finding your driver…',
  accepted: 'Driver is on the way',
  arriving: 'Your driver has arrived',
  in_progress: 'On your trip',
  completed: 'Trip complete',
  cancelled: 'Trip cancelled',
};

function ReceiptRow({ label, value, bold }) {
  return (
    <View style={styles.receiptRow}>
      <Text style={[styles.receiptLabel, bold && styles.receiptBold]}>{label}</Text>
      <Text style={[styles.receiptValue, bold && styles.receiptBold]}>{value}</Text>
    </View>
  );
}

export default function RiderRideScreen({ params }) {
  const { rideId } = params;
  const { navigate } = useNav();

  const [ride, setRide] = useState({
    id: rideId,
    status: 'requested',
    pickup: params.pickup,
    dropoff: params.dropoff,
    vehicleType: params.vehicleType,
    fare: params.fare,
  });
  const [driver, setDriver] = useState(null);
  const [driverLoc, setDriverLoc] = useState(null);
  const [notice, setNotice] = useState('');
  const [cancelReason, setCancelReason] = useState('');
  const [rating, setRating] = useState(0);

  useSocketEvents({
    'ride:accepted': (data) => {
      setRide(data.ride || {});
      setDriver(data.driver || null);
      if (data.driver) setDriverLoc({ lat: data.driver.lat, lng: data.driver.lng });
    },
    'ride:no_drivers': () => setNotice('No drivers are nearby yet — we\'ll keep looking…'),
    'driver:location_update': (data) => {
      if (data.rideId === rideId) setDriverLoc({ lat: data.lat, lng: data.lng });
    },
    'ride:arriving': (data) => setRide(data.ride || {}),
    'ride:in_progress': (data) => setRide(data.ride || {}),
    'ride:completed': (data) => setRide(data.ride || {}),
    'ride:cancelled': (data) => {
      setRide((r) => ({ ...r, status: 'cancelled' }));
      setCancelReason(
        data.reason === 'driver_disconnected'
          ? 'Your driver disconnected. Please request a new ride.'
          : 'This ride was cancelled.'
      );
    },
  });

  const status = ride.status;
  const showDriver = driver && ['accepted', 'arriving', 'in_progress'].includes(status);
  const enRoute = status === 'accepted' || status === 'arriving';
  const inTrip = status === 'in_progress';

  const polyline = useMemo(() => {
    if (inTrip && ride.pickup && ride.dropoff) return [ride.pickup, ride.dropoff];
    if (enRoute && driverLoc && ride.pickup) return [driverLoc, ride.pickup];
    return null;
  }, [inTrip, enRoute, driverLoc, ride.pickup, ride.dropoff]);

  const region = useMemo(() => {
    const c =
      ride.pickup && ride.dropoff
        ? midpoint(ride.pickup, ride.dropoff)
        : ride.pickup || { lat: DEFAULT_CITY.lat, lng: DEFAULT_CITY.lng };
    return { latitude: c.lat, longitude: c.lng, ...DEFAULT_DELTA };
  }, [ride.pickup, ride.dropoff]);

  const cancel = () => getSocket().emit('rider:cancel', { rideId });

  const submitRating = (n) => {
    setRating(n);
    getSocket().emit('ride:rate', { rideId, rating: n });
  };

  const done = () => navigate(SCREENS.Role);

  return (
    <View style={styles.container}>
      <MapView
        style={StyleSheet.absoluteFill}
        initialRegion={region}
        mapPadding={{ top: 140, right: 16, bottom: 300, left: 16 }}
      >
        {ride.pickup && (
          <Marker coordinate={{ latitude: ride.pickup.lat, longitude: ride.pickup.lng }} title="Pickup">
            <View style={[styles.dot, { backgroundColor: colors.accent }]} />
          </Marker>
        )}
        {ride.dropoff && (
          <Marker coordinate={{ latitude: ride.dropoff.lat, longitude: ride.dropoff.lng }} title="Drop-off">
            <Text style={styles.pin}>📍</Text>
          </Marker>
        )}
        {driverLoc && (
          <Marker
            coordinate={{ latitude: driverLoc.lat, longitude: driverLoc.lng }}
            anchor={{ x: 0.5, y: 0.5 }}
          >
            <View style={styles.driverBadge}>
              <Text style={styles.driverEmoji}>🚗</Text>
            </View>
          </Marker>
        )}
        {polyline && (
          <Polyline coordinates={polyline} strokeColor="#0C0C0E" strokeWidth={4} />
        )}
      </MapView>

      {/* Status card */}
      <View style={styles.statusCard}>
        {status === 'requested' ? (
          <View style={styles.centerBlock}>
            <ActivityIndicator color={colors.accent} size="large" />
            <Text style={styles.statusTitle}>{notice || STATUS_LABELS.requested}</Text>
            <Text style={styles.statusSub}>Matching you with the nearest available driver</Text>
          </View>
        ) : status === 'cancelled' ? (
          <View style={styles.centerBlock}>
            <Text style={styles.statusTitle}>{cancelReason}</Text>
            <TouchableOpacity style={styles.doneBtn} onPress={done}>
              <Text style={styles.doneText}>Back to home</Text>
            </TouchableOpacity>
          </View>
        ) : status === 'completed' ? (
          <ScrollView showsVerticalScrollIndicator={false}>
            <Text style={styles.thanks}>Thanks for riding with Rhino!</Text>
            <View style={styles.receipt}>
              <ReceiptRow label="Base fare" value={formatMoney(ride.fare?.base)} />
              <ReceiptRow label="Distance" value={formatMoney(ride.fare?.distance)} />
              <ReceiptRow label="Time" value={formatMoney(ride.fare?.time)} />
              <ReceiptRow label="Service fee" value={formatMoney(ride.fare?.serviceFee)} />
              <View style={styles.divider} />
              <ReceiptRow label="Total" value={formatMoney(ride.fare?.total)} bold />
            </View>
            <Text style={styles.rateLabel}>Rate your driver</Text>
            <Stars value={rating} onChange={submitRating} />
            <TouchableOpacity style={styles.doneBtn} onPress={done}>
              <Text style={styles.doneText}>Done</Text>
            </TouchableOpacity>
          </ScrollView>
        ) : (
          <View>
            {showDriver ? (
              <View style={styles.driverRow}>
                <View style={styles.avatar}>
                  <Text style={styles.avatarText}>{String(driver.name || '?').charAt(0)}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.statusTitle}>{STATUS_LABELS[status]}</Text>
                  <Text style={styles.statusSub}>
                    {driver.name} • {driver.vehicle?.color} {driver.vehicle?.make}{' '}
                    {driver.vehicle?.model} • {driver.vehicle?.plate}
                  </Text>
                </View>
                {ride.etaMin != null && <Text style={styles.eta}>{ride.etaMin} min</Text>}
              </View>
            ) : (
              <View style={styles.centerBlock}>
                <ActivityIndicator color={colors.accent} />
                <Text style={styles.statusTitle}>{STATUS_LABELS[status]}</Text>
              </View>
            )}
            {['requested', 'accepted', 'arriving'].includes(status) && (
              <TouchableOpacity style={styles.cancelBtn} onPress={cancel}>
                <Text style={styles.cancelText}>Cancel ride</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  statusCard: {
    position: 'absolute',
    left: 12,
    right: 12,
    bottom: 12,
    backgroundColor: colors.bg,
    borderRadius: radii.lg,
    padding: 18,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: -4 },
    elevation: 8,
    maxHeight: '55%',
  },
  centerBlock: { alignItems: 'center', paddingVertical: 8 },
  statusTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: colors.text,
    marginTop: 10,
    textAlign: 'center',
  },
  statusSub: { fontSize: 13, color: colors.muted, marginTop: 4, textAlign: 'center' },
  driverRow: { flexDirection: 'row', alignItems: 'center' },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  avatarText: { color: '#FFFFFF', fontSize: 18, fontWeight: '800' },
  eta: { fontSize: 15, fontWeight: '800', color: colors.accent, marginLeft: 8 },
  cancelBtn: {
    borderWidth: 1.5,
    borderColor: colors.danger,
    borderRadius: radii.pill,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 14,
  },
  cancelText: { color: colors.danger, fontWeight: '700', fontSize: 14 },
  thanks: { fontSize: 19, fontWeight: '900', color: colors.text, textAlign: 'center', marginVertical: 4 },
  receipt: {
    backgroundColor: colors.surface,
    borderRadius: radii.md,
    padding: 14,
    marginTop: 10,
  },
  receiptRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  receiptLabel: { fontSize: 14, color: colors.muted },
  receiptValue: { fontSize: 14, color: colors.text, fontWeight: '600' },
  receiptBold: { fontWeight: '900', color: colors.text, fontSize: 16 },
  divider: { height: 1, backgroundColor: colors.border, marginVertical: 6 },
  rateLabel: { textAlign: 'center', marginTop: 12, fontSize: 14, fontWeight: '700', color: colors.text },
  doneBtn: {
    backgroundColor: colors.accent,
    borderRadius: radii.pill,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 12,
  },
  doneText: { color: '#FFFFFF', fontWeight: '800', fontSize: 15 },
  dot: { width: 18, height: 18, borderRadius: 9, borderWidth: 3, borderColor: '#FFFFFF' },
  pin: { fontSize: 26 },
  driverBadge: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 6,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
  },
  driverEmoji: { fontSize: 18 },
});
