/** Landing screen: choose to ride or to drive. */
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useNav, SCREENS } from '../navigation';
import { colors, radii } from '../theme';

export default function RoleScreen() {
  const { navigate } = useNav();

  return (
    <View style={styles.container}>
      <View style={styles.hero}>
        <Text style={styles.logo}>Rhino</Text>
        <Text style={styles.tagline}>Get around. Earn your way.</Text>
      </View>

      <TouchableOpacity style={styles.riderCard} onPress={() => navigate(SCREENS.RiderHome)}>
        <Text style={styles.emoji}>🚗</Text>
        <View style={styles.cardBody}>
          <Text style={styles.cardTitle}>Book a ride</Text>
          <Text style={styles.cardSub}>Tap the map, pick a ride, get there</Text>
        </View>
        <Text style={styles.arrow}>›</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.driverCard} onPress={() => navigate(SCREENS.DriverHome)}>
        <Text style={styles.emojiLight}>🛞</Text>
        <View style={styles.cardBody}>
          <Text style={styles.cardTitleLight}>Drive & earn</Text>
          <Text style={styles.cardSubLight}>Go online and take ride requests</Text>
        </View>
        <Text style={styles.arrowLight}>›</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: colors.bg, justifyContent: 'flex-end' },
  hero: { marginBottom: 40 },
  logo: { fontSize: 40, fontWeight: '900', color: colors.text },
  tagline: { fontSize: 16, color: colors.muted, marginTop: 6 },
  riderCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radii.lg,
    padding: 18,
    marginBottom: 14,
    backgroundColor: colors.bg,
  },
  driverCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radii.lg,
    padding: 18,
    backgroundColor: colors.primary,
  },
  emoji: { fontSize: 30, marginRight: 14 },
  emojiLight: { fontSize: 30, marginRight: 14 },
  cardBody: { flex: 1 },
  cardTitle: { fontSize: 18, fontWeight: '800', color: colors.text },
  cardSub: { fontSize: 13, color: colors.muted, marginTop: 3 },
  cardTitleLight: { fontSize: 18, fontWeight: '800', color: '#FFFFFF' },
  cardSubLight: { fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 3 },
  arrow: { fontSize: 28, color: colors.muted, marginLeft: 8 },
  arrowLight: { fontSize: 28, color: '#FFFFFF', marginLeft: 8 },
});
