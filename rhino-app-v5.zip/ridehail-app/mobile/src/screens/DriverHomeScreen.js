/**
 * Driver home: set up your car, go online, wait for ride requests.
 */
import React, { useEffect, useRef, useState } from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { connectSocket, getSocket } from '../lib/api';
import { getCurrentPosition } from '../lib/location';
import { formatMoney, randomOffset } from '../geo';
import { DEFAULT_CITY } from '../constants';
import { colors, radii } from '../theme';
import { SCREENS, useNav } from '../navigation';
import { useSocketEvents } from '../hooks/useSocketEvents';

const VEHICLE_TYPES = [
  { id: 'ride', label: '🚗 Ride' },
  { id: 'comfort', label: '🚘 Comfort' },
  { id: 'xl', label: '🚙 XL' },
];

export default function DriverHomeScreen() {
  const { navigate } = useNav();
  const driverId = useRef('D' + Math.random().toString(36).slice(2, 10)).current;

  const [name, setName] = useState('Alex');
  const [vehicleType, setVehicleType] = useState('ride');
  const [vehicle, setVehicle] = useState({
    make: 'Toyota',
    model: 'Corolla',
    color: 'Black',
    plate: 'ABC 123',
  });
  const [online, setOnline] = useState(false);
  const [stats, setStats] = useState({ trips: 0, earnings: 0 });
  const locTimer = useRef(null);

  useSocketEvents({
    'ride:request': (payload) => {
      if (online) navigate(SCREENS.DriverRequest, { ...payload, driverId });
    },
    'ride:completed': (data) => {
      setStats((s) => ({
        trips: s.trips + 1,
        earnings: s.earnings + (data.ride?.fare?.total || 0),
      }));
    },
  });

  useEffect(
    () => () => {
      if (locTimer.current) clearInterval(locTimer.current);
    },
    []
  );

  async function goOnline() {
    const current = await getCurrentPosition();
    // Small random offset when falling back to the demo city, so two test
    // drivers on the same machine don't sit at the exact same spot.
    const pos =
      current || randomOffset(DEFAULT_CITY.lat, DEFAULT_CITY.lng, 3);
    const socket = connectSocket();
    socket.emit('driver:online', {
      driverId,
      name,
      vehicleType,
      vehicle,
      lat: pos.lat,
      lng: pos.lng,
    });
    setOnline(true);
    locTimer.current = setInterval(() => {
      socket.emit('driver:location', { driverId, lat: pos.lat, lng: pos.lng });
    }, 5000);
  }

  function goOffline() {
    if (locTimer.current) clearInterval(locTimer.current);
    const socket = getSocket();
    if (socket) socket.emit('driver:offline', { driverId });
    setOnline(false);
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Drive & earn</Text>
        <View style={[styles.badge, online ? styles.badgeOn : styles.badgeOff]}>
          <View style={[styles.badgeDot, { backgroundColor: online ? colors.accent : colors.muted }]} />
          <Text style={[styles.badgeText, { color: online ? colors.accent : colors.muted }]}>
            {online ? 'Online' : 'Offline'}
          </Text>
        </View>
      </View>

      {/* Profile / vehicle form */}
      <View style={styles.form}>
        <Text style={styles.label}>Your name</Text>
        <TextInput
          style={styles.input}
          value={name}
          onChangeText={setName}
          editable={!online}
          placeholder="Driver name"
          placeholderTextColor={colors.muted}
        />
        <Text style={styles.label}>Vehicle type</Text>
        <View style={styles.chipRow}>
          {VEHICLE_TYPES.map((v) => (
            <TouchableOpacity
              key={v.id}
              style={[styles.chip, vehicleType === v.id && styles.chipSelected]}
              onPress={() => setVehicleType(v.id)}
              disabled={online}
            >
              <Text
                style={[styles.chipText, vehicleType === v.id && styles.chipTextSelected]}
              >
                {v.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        <View style={styles.row2}>
          <View style={{ flex: 1, marginRight: 8 }}>
            <Text style={styles.label}>Make</Text>
            <TextInput
              style={styles.input}
              value={vehicle.make}
              onChangeText={(t) => setVehicle({ ...vehicle, make: t })}
              editable={!online}
            />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.label}>Model</Text>
            <TextInput
              style={styles.input}
              value={vehicle.model}
              onChangeText={(t) => setVehicle({ ...vehicle, model: t })}
              editable={!online}
            />
          </View>
        </View>
        <View style={styles.row2}>
          <View style={{ flex: 1, marginRight: 8 }}>
            <Text style={styles.label}>Color</Text>
            <TextInput
              style={styles.input}
              value={vehicle.color}
              onChangeText={(t) => setVehicle({ ...vehicle, color: t })}
              editable={!online}
            />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.label}>Plate</Text>
            <TextInput
              style={styles.input}
              value={vehicle.plate}
              onChangeText={(t) => setVehicle({ ...vehicle, plate: t })}
              editable={!online}
              autoCapitalize="characters"
            />
          </View>
        </View>
      </View>

      {/* Online toggle */}
      {online ? (
        <TouchableOpacity style={styles.offlineBtn} onPress={goOffline}>
          <Text style={styles.offlineText}>Go offline</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity style={styles.onlineBtn} onPress={goOnline}>
          <Text style={styles.onlineText}>Go online</Text>
        </TouchableOpacity>
      )}

      {/* Stats */}
      {online && (
        <View style={styles.statsCard}>
          <View style={styles.stat}>
            <Text style={styles.statValue}>{stats.trips}</Text>
            <Text style={styles.statLabel}>Trips</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.stat}>
            <Text style={styles.statValue}>{formatMoney(stats.earnings)}</Text>
            <Text style={styles.statLabel}>Today's earnings</Text>
          </View>
        </View>
      )}

      {online && (
        <Text style={styles.waiting}>Listening for ride requests near you…</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  title: { fontSize: 26, fontWeight: '900', color: colors.text },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radii.pill,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  badgeOn: { backgroundColor: colors.accentSoft },
  badgeOff: { backgroundColor: colors.surface },
  badgeDot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  badgeText: { fontWeight: '700', fontSize: 13 },
  form: { backgroundColor: colors.surface, borderRadius: radii.lg, padding: 16 },
  label: { fontSize: 12, fontWeight: '700', color: colors.muted, marginTop: 12, marginBottom: 6 },
  input: {
    backgroundColor: colors.bg,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.sm,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
    color: colors.text,
  },
  chipRow: { flexDirection: 'row' },
  chip: {
    flex: 1,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radii.pill,
    paddingVertical: 10,
    alignItems: 'center',
    marginRight: 8,
    backgroundColor: colors.bg,
  },
  chipSelected: { borderColor: colors.accent, backgroundColor: colors.accentSoft },
  chipText: { fontWeight: '700', color: colors.muted },
  chipTextSelected: { color: colors.accent },
  row2: { flexDirection: 'row' },
  onlineBtn: {
    backgroundColor: colors.accent,
    borderRadius: radii.pill,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 16,
  },
  onlineText: { color: '#FFFFFF', fontWeight: '800', fontSize: 17 },
  offlineBtn: {
    backgroundColor: colors.primary,
    borderRadius: radii.pill,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 16,
  },
  offlineText: { color: '#FFFFFF', fontWeight: '800', fontSize: 17 },
  statsCard: {
    flexDirection: 'row',
    backgroundColor: colors.primary,
    borderRadius: radii.lg,
    padding: 18,
    marginTop: 16,
  },
  stat: { flex: 1, alignItems: 'center' },
  statDivider: { width: 1, backgroundColor: 'rgba(255,255,255,0.2)', marginHorizontal: 8 },
  statValue: { color: '#FFFFFF', fontSize: 22, fontWeight: '900' },
  statLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 12, marginTop: 2 },
  waiting: { textAlign: 'center', color: colors.muted, fontSize: 13, marginTop: 14 },
});
