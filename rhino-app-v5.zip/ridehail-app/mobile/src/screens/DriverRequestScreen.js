/**
 * Incoming ride request: review pickup/drop-off/fare, then accept or decline.
 */
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { getSocket } from '../lib/api';
import { reverseGeocode } from '../lib/geocode';
import { formatDuration, formatMoney } from '../geo';
import { colors, radii } from '../theme';
import { SCREENS, useNav } from '../navigation';

export default function DriverRequestScreen({ params }) {
  const { navigate, goBack } = useNav();
  const [addr, setAddr] = useState({ pickup: null, dropoff: null });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [p, d] = await Promise.all([
        reverseGeocode(params.pickup.lat, params.pickup.lng),
        reverseGeocode(params.dropoff.lat, params.dropoff.lng),
      ]);
      if (!cancelled) setAddr({ pickup: p, dropoff: d });
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  function accept() {
    getSocket().emit('driver:accept', { rideId: params.rideId });
    navigate(SCREENS.DriverRide, {
      rideId: params.rideId,
      request: params,
      driverId: params.driverId,
    });
  }

  function decline() {
    getSocket().emit('driver:decline', { rideId: params.rideId });
    goBack();
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>New ride request</Text>
        <Text style={styles.sub}>
          {params.etaMin} min away • {params.rider?.name || 'Rider'}
        </Text>
      </View>

      <View style={styles.fareCircle}>
        <Text style={styles.fare}>{formatMoney(params.fare?.total)}</Text>
        <Text style={styles.fareSub}>{params.fare?.vehicleName || 'Ride'}</Text>
      </View>

      <View style={styles.routeCard}>
        <View style={styles.routeRow}>
          <View style={[styles.routeDot, { backgroundColor: colors.accent }]} />
          <Text style={styles.routeText} numberOfLines={2}>
            {addr.pickup || `Pickup (${params.pickup.lat.toFixed(4)}, ${params.pickup.lng.toFixed(4)})`}
          </Text>
        </View>
        <View style={styles.routeLine} />
        <View style={styles.routeRow}>
          <View style={[styles.routeDot, { backgroundColor: colors.danger }]} />
          <Text style={styles.routeText} numberOfLines={2}>
            {addr.dropoff ||
              `Drop-off (${params.dropoff.lat.toFixed(4)}, ${params.dropoff.lng.toFixed(4)})`}
          </Text>
        </View>
        <Text style={styles.tripMeta}>
          {params.fare?.distance != null ? params.fare.distance.toFixed(1) : '—'} km • ~
          {formatDuration(params.fare?.time || 5)}
        </Text>
      </View>

      <View style={styles.actions}>
        <TouchableOpacity style={styles.declineBtn} onPress={decline}>
          <Text style={styles.declineText}>Decline</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.acceptBtn} onPress={accept}>
          <Text style={styles.acceptText}>Accept</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: colors.bg, justifyContent: 'center' },
  header: { alignItems: 'center', marginBottom: 22 },
  title: { fontSize: 24, fontWeight: '900', color: colors.text },
  sub: { fontSize: 14, color: colors.muted, marginTop: 6 },
  fareCircle: {
    alignSelf: 'center',
    width: 130,
    height: 130,
    borderRadius: 65,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 22,
  },
  fare: { color: '#FFFFFF', fontSize: 26, fontWeight: '900' },
  fareSub: { color: 'rgba(255,255,255,0.7)', fontSize: 13, marginTop: 2 },
  routeCard: {
    backgroundColor: colors.surface,
    borderRadius: radii.lg,
    padding: 18,
  },
  routeRow: { flexDirection: 'row', alignItems: 'center' },
  routeDot: { width: 12, height: 12, borderRadius: 6, marginRight: 12 },
  routeText: { flex: 1, fontSize: 14, color: colors.text, fontWeight: '600' },
  routeLine: { width: 2, height: 18, backgroundColor: colors.border, marginLeft: 5, marginVertical: 4 },
  tripMeta: { fontSize: 12, color: colors.muted, marginTop: 10, marginLeft: 24 },
  actions: { flexDirection: 'row', marginTop: 24 },
  declineBtn: {
    flex: 1,
    borderWidth: 1.5,
    borderColor: colors.danger,
    borderRadius: radii.pill,
    paddingVertical: 16,
    alignItems: 'center',
    marginRight: 10,
  },
  declineText: { color: colors.danger, fontWeight: '800', fontSize: 16 },
  acceptBtn: {
    flex: 1,
    backgroundColor: colors.accent,
    borderRadius: radii.pill,
    paddingVertical: 16,
    alignItems: 'center',
    marginLeft: 10,
  },
  acceptText: { color: '#FFFFFF', fontWeight: '800', fontSize: 16 },
});
