/**
 * Driver live-trip screen: walk the trip forward
 * (arrive -> start -> complete) while broadcasting a simulated GPS position
 * so the rider can watch you approach on their map.
 */
import React, { useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import { getSocket } from '../lib/api';
import { formatMoney, haversineKm, midpoint } from '../geo';
import { DEFAULT_CITY, DEFAULT_DELTA } from '../constants';
import { colors, radii } from '../theme';
import { SCREENS, useNav } from '../navigation';
import { useSocketEvents } from '../hooks/useSocketEvents';

export default function DriverRideScreen({ params }) {
  const { rideId, request, driverId } = params;
  const { navigate } = useNav();

  const [ride, setRide] = useState(
    request ? { ...request, status: 'requested' } : { id: rideId, status: 'requested' }
  );
  const [notice, setNotice] = useState('');
  const [pos, setPos] = useState(null);
  const simTimer = useRef(null);

  useSocketEvents({
    'ride:accepted': (data) => {
      setRide(data.ride || {});
      const d = data.ride && data.ride.driver;
      if (d && typeof d.lat === 'number') setPos({ lat: d.lat, lng: d.lng });
    },
    'ride:arriving': (data) => setRide(data.ride || {}),
    'ride:in_progress': (data) => setRide(data.ride || {}),
    'ride:completed': (data) => setRide(data.ride || {}),
    'ride:cancelled': (data) => {
      setRide((r) => ({ ...r, status: 'cancelled' }));
      setNotice(
        data.reason === 'rider_cancelled' ? 'The rider cancelled this trip.' : 'This trip was cancelled.'
      );
    },
  });

  /* Simulated GPS: move toward the active target and broadcast it to the rider. */
  useEffect(() => {
    if (['completed', 'cancelled'].includes(ride.status)) return undefined;
    simTimer.current = setInterval(() => {
      setPos((current) => {
        const base = current || ride.pickup;
        if (!base || !ride.pickup || !ride.dropoff) return current;
        const target = ride.status === 'in_progress' ? ride.dropoff : ride.pickup;
        const total = haversineKm(base.lat, base.lng, target.lat, target.lng);
        const stepKm = 0.25;
        const frac = total <= stepKm ? 1 : stepKm / total;
        const next = {
          lat: base.lat + (target.lat - base.lat) * frac,
          lng: base.lng + (target.lng - base.lng) * frac,
        };
        getSocket().emit('driver:location', { driverId, lat: next.lat, lng: next.lng });
        return next;
      });
    }, 3000);
    return () => clearInterval(simTimer.current);
  }, [ride.status, ride.pickup, ride.dropoff, driverId]);

  useEffect(() => () => clearInterval(simTimer.current), []);

  const status = ride.status;
  const markerLoc = pos || ride.pickup;

  const polyline = (() => {
    if (status === 'in_progress' && ride.pickup && ride.dropoff)
      return [ride.pickup, ride.dropoff];
    if ((status === 'accepted' || status === 'arriving') && markerLoc && ride.pickup)
      return [markerLoc, ride.pickup];
    return null;
  })();

  const region = (() => {
    const c =
      ride.pickup && ride.dropoff
        ? midpoint(ride.pickup, ride.dropoff)
        : ride.pickup || { lat: DEFAULT_CITY.lat, lng: DEFAULT_CITY.lng };
    return { latitude: c.lat, longitude: c.lng, ...DEFAULT_DELTA };
  })();

  const advance = (event) => getSocket().emit(event, { rideId });
  const finish = () => navigate(SCREENS.DriverHome);

  return (
    <View style={styles.container}>
      <MapView
        style={StyleSheet.absoluteFill}
        initialRegion={region}
        mapPadding={{ top: 140, right: 16, bottom: 300, left: 16 }}
      >
        {ride.pickup && (
          <Marker coordinate={{ latitude: ride.pickup.lat, longitude: ride.pickup.lng }} title="Pickup">
            <View style={[styles.dot, { backgroundColor: colors.accent }]} />
          </Marker>
        )}
        {ride.dropoff && (
          <Marker coordinate={{ latitude: ride.dropoff.lat, longitude: ride.dropoff.lng }} title="Drop-off">
            <Text style={styles.pin}>📍</Text>
          </Marker>
        )}
        {markerLoc && (
          <Marker
            coordinate={{ latitude: markerLoc.lat, longitude: markerLoc.lng }}
            anchor={{ x: 0.5, y: 0.5 }}
          >
            <View style={styles.driverBadge}>
              <Text style={styles.driverEmoji}>🚗</Text>
            </View>
          </Marker>
        )}
        {polyline && <Polyline coordinates={polyline} strokeColor="#0C0C0E" strokeWidth={4} />}
      </MapView>

      <View style={styles.statusCard}>
        {status === 'completed' ? (
          <View style={styles.centerBlock}>
            <Text style={styles.doneTitle}>Trip complete!</Text>
            <Text style={styles.doneFare}>{formatMoney(ride.fare?.total)} earned</Text>
            <TouchableOpacity style={styles.primaryBtn} onPress={finish}>
              <Text style={styles.primaryText}>Done</Text>
            </TouchableOpacity>
          </View>
        ) : status === 'cancelled' ? (
          <View style={styles.centerBlock}>
            <Text style={styles.statusTitle}>{notice}</Text>
            <TouchableOpacity style={styles.primaryBtn} onPress={finish}>
              <Text style={styles.primaryText}>Back to home</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View>
            <View style={styles.riderRow}>
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>
                  {String(ride.rider?.name || 'R').charAt(0)}
                </Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.statusTitle}>
                  {ride.rider?.name || 'Rider'} • {formatMoney(ride.fare?.total)}
                </Text>
                <Text style={styles.statusSub}>
                  {ride.pickup?.lat.toFixed(4)},{ride.pickup?.lng.toFixed(4)} →{' '}
                  {ride.dropoff?.lat.toFixed(4)},{ride.dropoff?.lng.toFixed(4)}
                </Text>
              </View>
            </View>

            {status === 'requested' && (
              <TouchableOpacity style={styles.primaryBtn} onPress={() => advance('driver:accept')}>
                <Text style={styles.primaryText}>Accept ride</Text>
              </TouchableOpacity>
            )}
            {status === 'accepted' && (
              <TouchableOpacity style={styles.primaryBtn} onPress={() => advance('driver:arrived')}>
                <Text style={styles.primaryText}>I've arrived at pickup</Text>
              </TouchableOpacity>
            )}
            {status === 'arriving' && (
              <TouchableOpacity style={styles.primaryBtn} onPress={() => advance('driver:start')}>
                <Text style={styles.primaryText}>Start trip</Text>
              </TouchableOpacity>
            )}
            {status === 'in_progress' && (
              <TouchableOpacity style={styles.primaryBtn} onPress={() => advance('driver:complete')}>
                <Text style={styles.primaryText}>Complete trip</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  statusCard: {
    position: 'absolute',
    left: 12,
    right: 12,
    bottom: 12,
    backgroundColor: colors.bg,
    borderRadius: radii.lg,
    padding: 18,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: -4 },
    elevation: 8,
  },
  centerBlock: { alignItems: 'center', paddingVertical: 8 },
  statusTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: colors.text,
    textAlign: 'center',
  },
  statusSub: { fontSize: 12, color: colors.muted, marginTop: 4, textAlign: 'center' },
  riderRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  avatarText: { color: '#FFFFFF', fontSize: 18, fontWeight: '800' },
  primaryBtn: {
    backgroundColor: colors.accent,
    borderRadius: radii.pill,
    paddingVertical: 15,
    alignItems: 'center',
  },
  primaryText: { color: '#FFFFFF', fontWeight: '800', fontSize: 16 },
  doneTitle: { fontSize: 20, fontWeight: '900', color: colors.text },
  doneFare: { fontSize: 30, fontWeight: '900', color: colors.accent, marginVertical: 8 },
  dot: { width: 18, height: 18, borderRadius: 9, borderWidth: 3, borderColor: '#FFFFFF' },
  pin: { fontSize: 26 },
  driverBadge: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 6,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
  },
  driverEmoji: { fontSize: 18 },
});
