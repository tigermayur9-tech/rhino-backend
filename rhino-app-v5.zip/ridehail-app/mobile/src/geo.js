/** Client-side geo + formatting helpers. */
const EARTH_RADIUS_KM = 6371;
const toRad = (deg) => (deg * Math.PI) / 180;

export function haversineKm(lat1, lon1, lat2, lon2) {
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return EARTH_RADIUS_KM * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function estimateDurationMin(km) {
  return (km / 24) * 60 + 2;
}

export function formatDuration(min) {
  const m = Math.max(1, Math.round(min));
  if (m < 60) return `${m} min`;
  const h = Math.floor(m / 60);
  const rest = m % 60;
  return rest ? `${h} hr ${rest} min` : `${h} hr`;
}

export function formatMoney(n) {
  return `$${(n || 0).toFixed(2)}`;
}

export function midpoint(a, b) {
  return { lat: (a.lat + b.lat) / 2, lng: (a.lng + b.lng) / 2 };
}

/** Small random offset (km) — handy so two test drivers don't sit at the exact same spot. */
export function randomOffset(lat, lng, km = 2) {
  const dLat = ((Math.random() - 0.5) * 2 * km) / 111;
  const dLng = ((Math.random() - 0.5) * 2 * km) / (111 * Math.cos(toRad(lat)) || 1);
  return { lat: lat + dLat, lng: lng + dLng };
}
