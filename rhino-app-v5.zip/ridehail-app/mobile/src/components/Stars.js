/** Simple 5-star rating input. */
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

export default function Stars({ value = 0, onChange }) {
  return (
    <View style={styles.row}>
      {[1, 2, 3, 4, 5].map((n) => (
        <TouchableOpacity key={n} onPress={() => onChange && onChange(n)} hitSlop={8}>
          <Text style={[styles.star, { color: n <= value ? '#FFB400' : '#D9D9D9' }]}>★</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', justifyContent: 'center', marginVertical: 10 },
  star: { fontSize: 36, marginHorizontal: 6 },
});
