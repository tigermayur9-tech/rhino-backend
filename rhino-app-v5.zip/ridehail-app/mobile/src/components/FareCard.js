/** Selectable vehicle/fare option card (like Uber's ride-type picker). */
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { formatDuration, formatMoney } from '../geo';
import { colors, radii } from '../theme';

const ICONS = { ride: '🚗', comfort: '🚘', xl: '🚙' };

export default function FareCard({ fare, selected, onPress }) {
  return (
    <TouchableOpacity
      style={[styles.card, selected && styles.selected]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <Text style={styles.icon}>{ICONS[fare.vehicleType] || '🚗'}</Text>
      <View style={styles.info}>
        <Text style={styles.name}>{fare.vehicleName}</Text>
        <Text style={styles.blurb} numberOfLines={1}>
          {fare.blurb}
        </Text>
        <Text style={styles.meta}>
          ~{formatDuration(fare.time)} • {fare.seats} seats
        </Text>
      </View>
      <Text style={[styles.price, selected && styles.priceSelected]}>
        {formatMoney(fare.total)}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radii.md,
    padding: 14,
    marginBottom: 10,
    backgroundColor: colors.bg,
  },
  selected: {
    borderColor: colors.accent,
    backgroundColor: colors.accentSoft,
  },
  icon: { fontSize: 26, marginRight: 12 },
  info: { flex: 1 },
  name: { fontSize: 16, fontWeight: '700', color: colors.text },
  blurb: { fontSize: 12, color: colors.muted, marginTop: 2 },
  meta: { fontSize: 12, color: colors.muted, marginTop: 4 },
  price: { fontSize: 17, fontWeight: '800', color: colors.text, marginLeft: 8 },
  priceSelected: { color: colors.accent },
});
