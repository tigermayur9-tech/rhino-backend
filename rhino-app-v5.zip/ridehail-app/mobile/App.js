/**
 * Rhino — rider + driver app (Expo / React Native).
 */
import React from 'react';
import { SafeAreaView, StatusBar, StyleSheet } from 'react-native';
import { NavigationProvider, SCREENS, useNav } from './src/navigation';
import RoleScreen from './src/screens/RoleScreen';
import RiderHomeScreen from './src/screens/RiderHomeScreen';
import RiderRideScreen from './src/screens/RiderRideScreen';
import DriverHomeScreen from './src/screens/DriverHomeScreen';
import DriverRequestScreen from './src/screens/DriverRequestScreen';
import DriverRideScreen from './src/screens/DriverRideScreen';

function Router() {
  const { route } = useNav();
  switch (route.name) {
    case SCREENS.RiderHome:
      return <RiderHomeScreen />;
    case SCREENS.RiderRide:
      return <RiderRideScreen params={route.params} />;
    case SCREENS.DriverHome:
      return <DriverHomeScreen />;
    case SCREENS.DriverRequest:
      return <DriverRequestScreen params={route.params} />;
    case SCREENS.DriverRide:
      return <DriverRideScreen params={route.params} />;
    default:
      return <RoleScreen />;
  }
}

export default function App() {
  return (
    <NavigationProvider>
      <SafeAreaView style={styles.root}>
        <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
        <Router />
      </SafeAreaView>
    </NavigationProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#FFFFFF' },
});
